/*
╾━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╼
THIS SCRIPT RECODE BY KYLEOFFIC
INITIAL SCRIPT BY ZASSBTC
SUPPORT BY CANSS
DONT DELETED CREADIT FOR SUPPORT CREATOR
╾━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╼
*/
const { default:
makeWASocket,
fetchLatestBaileysVersion, 
downloadContentFromMessage,
useMultiFileAuthState,
BufferJSON,
WA_DEFAULT_EPHEMERAL,
generateWAMessageFromContent,
proto, generateWAMessageContent,
generateWAMessage,
prepareWAMessageMedia,
areJidsSameUser,
getContentType
} = require('naruyaizumi')
const os = require('os')
const fs = require('fs') 
const fsx = require('fs-extra')
const FormData = require('form-data');
const path = require('path')
const cheerio = require('cheerio') ;
const util = require('util')
const chalk = require('chalk')
const moment = require('moment-timezone')
const speed = require('performance-now')
const ms = toMs = require('ms')
const axios = require('axios')
const fetch = require('node-fetch')
const pino = require('pino')
coterest = require('./lib/pinterest')
const readline = require("readline");
const crypto = require('crypto');
const { exec, spawn, execSync } = require("child_process")
const { performance } = require('perf_hooks')
const more = String.fromCharCode(8206)
const readmore = more.repeat(4001)
const { toAudio, toPTT, toVideo, ffmpeg, addExifAvatar } = require('./lib/converter')
const { smsg, getGroupAdmins, formatp, jam, formatDate, getTime, isUrl, await, sleep, clockString, msToDate, sort, toNumber, enumGetKey, runtime, fetchJson, getBuffer, json, delay, format, logic, generateProfilePicture, parseMention, getRandom, pickRandom, reSize } = require('./lib/myfunc')
let afk = require("./lib/afk");
const { rankDB, saveRank, updateRank } = require('./lib/rank')
const NodeCache = require('node-cache');
const { addAccountToGroup, removeAccountFromGroup, listAccounts, toggleGroup } = require('./lib/tiktok_handler/tiktokup');
let _owner = JSON.parse(fs.readFileSync('./database/owner.json'))
let owner = JSON.parse(fs.readFileSync('./database/owner.json'))
let _afk = JSON.parse(fs.readFileSync('./database/afk-user.json'))
let hit = JSON.parse(fs.readFileSync('./database/total-hit-user.json'))


const { handleAbsent, handleCheckAbsent, handleWeeklyRecap } = require('./lib/absen')

const detekPath = './database/detek.json';
// Fungsi load detek.json
function loadDetek() {
    let detekData = {};
    try { detekData = JSON.parse(fs.readFileSync(detekPath, 'utf-8')); } catch {}
    return detekData;
}
// Fungsi save detek.json
function saveDetek(data) {
    fs.writeFileSync(detekPath, JSON.stringify(data, null, 2));
}
const tiktokDBFile = './database/tiktok.json'; // Path database
let tiktokDB = {};
if (fs.existsSync(tiktokDBFile)) {
    tiktokDB = JSON.parse(fs.readFileSync(tiktokDBFile));
}

function saveTiktokDB() {
    fs.writeFileSync(tiktokDBFile, JSON.stringify(tiktokDB, null, 2));
}

//——————————[ TIME ]——————————//

const xtime = moment.tz('Asia/Kolkata').format('HH:mm:ss')
const xdate = moment.tz('Asia/Kolkata').format('DD/MM/YYYY')
const time2 = moment().tz('Asia/Kolkata').format('HH:mm:ss')  
if(time2 < "23:59:00"){
var kylesalam = `Good Night 🌌`
 }
 if(time2 < "19:00:00"){
var kylesalam = `Good Evening 🌃`
 }
 if(time2 < "18:00:00"){
var kylesalam = `Good Evening 🌃`
 }
 if(time2 < "15:00:00"){
var kylesalam = `Good Afternoon 🌅`
 }
 if(time2 < "11:00:00"){
var kylesalam = `Good Morning 🌄`
 }
 if(time2 < "05:00:00"){
var kylesalam = `Good Morning 🌄`
 } 
module.exports = Kyle = async (Kyle, m, msg, chatUpdate, store) => {
    try {
        const {
            type,
            quotedMsg,
            mentioned,
            now,
            fromMe
        } = m

        
//——————————[ CONST PELER = DIA ]——————————//
const body = (m.mtype === 'conversation' && m.message.conversation) ? m.message.conversation : (m.mtype == 'imageMessage') && m.message.imageMessage.caption ? m.message.imageMessage.caption : (m.mtype == 'documentMessage') && m.message.documentMessage.caption ? m.message.documentMessage.caption : (m.mtype == 'videoMessage') && m.message.videoMessage.caption ? m.message.videoMessage.caption : (m.mtype == 'extendedTextMessage') && m.message.extendedTextMessage.text ? m.message.extendedTextMessage.text : (m.mtype == 'buttonsResponseMessage' && m.message.buttonsResponseMessage.selectedButtonId) ? m.message.buttonsResponseMessage.selectedButtonId : (m.mtype == 'templateButtonReplyMessage') && m.message.templateButtonReplyMessage.selectedId ? m.message.templateButtonReplyMessage.selectedId : m.mtype === 'interactiveResponseMessage' ? JSON.parse(m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson).id : '.'
const budy = (typeof m.text == 'string' ? m.text : '.')
const prefa = global.prefa instanceof Array ? global.prefa : [global.prefa]
const prefix = prefa.find(p => body.startsWith(p))
const isCmd = body.startsWith(prefix);
const command = isCmd ? body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase() : '';
        const args = body.trim().split(/ +/).slice(1)
        const full_args = body.replace(command, '').slice(1).trim()
        const pushname = m.pushName || "Anomali"
        const botNumber = await Kyle.decodeJid(Kyle.user.id)
        const itsMe = m.sender == botNumber ? true : false
        const sender = m.key.fromMe ? (Kyle.user.id.split(':')[0]+'@s.whatsapp.net' || Kyle.user.id) : (m.key.participant || m.key.remoteJid)
        const text = q = args.join(" ")
        const from = m.key.remoteJid
        const fatkuns = (m.quoted || m)
        const quoted = (fatkuns.mtype == 'buttonsMessage') ? fatkuns[Object.keys(fatkuns)[1]] : (fatkuns.mtype == 'templateMessage') ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] : (fatkuns.mtype == 'product') ? fatkuns[Object.keys(fatkuns)[0]] : m.quoted ? m.quoted : m
        const mime = (quoted.msg || quoted).mimetype || ''
        const qmsg = (quoted.msg || quoted)
        const isMedia = /image|video|sticker|audio/.test(mime)
        const isImage = (type == 'imageMessage')
        const isVideo = (type == 'videoMessage')
        const isAudio = (type == 'audioMessage')
        const isText = (type == 'textMessage')
        const isSticker = (type == 'stickerMessage')
        const isQuotedText = type === 'extendexTextMessage' && content.includes('textMessage')
        const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage')
        const isQuotedLocation = type === 'extendedTextMessage' && content.includes('locationMessage')
        const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage')
        const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage')
        const isQuotedAudio = type === 'extendedTextMessage' && content.includes('audioMessage')
        const isQuotedContact = type === 'extendedTextMessage' && content.includes('contactMessage')
        const isQuotedDocument = type === 'extendedTextMessage' && content.includes('documentMessage')
        const sticker = []
        const isAfkOn = afk.checkAfkUser(m.sender, _afk)
        const isGroup = m.key.remoteJid.endsWith('@g.us')
        const groupMetadata = isGroup 
  ? await Kyle.groupMetadata(m.chat).catch(() => ({})) 
  : {};
const groupName = groupMetadata.subject || '';
const participants = groupMetadata.participants || [];
const groupAdmins = participants.filter(v => v.admin).map(v => v.id);
const groupOwner = groupMetadata.owner || '';
const groupMembers = groupMetadata.participants || [];
        const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
        const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
        
        const isGroupOwner = m.isGroup ? (groupOwner ? groupOwner : groupAdmins).includes(m.sender) : false


        const KyleId = Kyle.user.id.split(':')[0];
        const senderbot = m.key.fromMe ? Kyle.user.id.split(':')[0] + "@s.whatsapp.net" || Kyle.user.id : m.key.participant || m.key.remoteJid;
        const senderId = senderbot.split('@')[0];
        const isBot = KyleId.includes(senderId);
const ppUrl = await Kyle.profilePictureUrl(m.chat, 'image').catch(() => global.imgthumb);
if (m.key.fromMe) return             
//——————————[ DATABASE ]——————————//
const db = JSON.parse(fs.readFileSync("./database/set.json"))
const senderNumber = sender.split('@')[0]
const ownerNumber = JSON.parse(fs.readFileSync("./database/owner.json"))
const OWNER_FILE = path.join(__dirname, './database/owner.json');
const isCreator = ownerNumber.includes(senderNumber) || isBot || senderNumber === ownernumber;

//——————————[ PRESET QUOTED ]——————————//


const qCans = {key: { participant: "0@s.whatsapp.net", remoteJid: `status@broadcast` }, message: {contactMessage: {displayName: `${global.ownername}`, isBusinessVerified: true }}}

const qtext = { key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(m.chat ? { remoteJid: "0@s.whatsapp.net"} : {}) },'message': {extendedTextMessage: {text: "Thank you for using my services"}}}

//——————————[ FUNCTION ]——————————//

        async function balas(teks) {
            const po = {
                    contextInfo: {
                        externalAdReply: {
                            title: global.botname,
                            body: `Version ${versi}`,
                            thumbnailUrl: ppUrl,
                            sourceUrl: '',
                            mediaType: 1,
                            renderLargerThumbnail: false
                    }
                },
                text: teks
            };
            return Kyle.sendMessage(m.chat, po, { quoted: qCans }
            );
        };
        
        async function reply(teks) {
        const mek = { text: teks };
        return Kyle.sendMessage(m.chat, mek, { quoted: qCans }
        );
        };

        Kyle.sendPresenceUpdate('uavailable', from)
        let list = []
        
	function saveDb() {
    fs.writeFileSync('./database/set.json', JSON.stringify(db, null, 2));
}
let ownerList = [];
if (fs.existsSync(OWNER_FILE)) {
    try {
        ownerList = JSON.parse(fs.readFileSync(OWNER_FILE));
    } catch (e) {
        console.error("Gagal membaca owner.json:", e);
        ownerList = [];
    }
} else {
    fs.writeFileSync(OWNER_FILE, JSON.stringify([], null, 2));
}
async function saveOwnerList() {
    fs.writeFileSync(OWNER_FILE, JSON.stringify(ownerList, null, 2));
}
        const func = {
  capital: (text) => {
    return text ? text.replace(/\b\w/g, l => l.toUpperCase()) : '';
  }
};
const ments = (text) => {return text.match('@') ? [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net') : []}
const axios = require("axios");
function pickRandom(list) {
	return list[Math.floor(list.length * Math.random())]
}

const font = (text, style = 1) => {
  var xStr = 'abcdefghijklmnopqrstuvwxyz1234567890'.split('');
  var yStr = {
    1: 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀꜱᴛᴜᴠᴡxʏᴢ1234567890'
  };
  var replacer = [];
  xStr.map((v, i) =>
    replacer.push({
      original: v,
      convert: yStr[style].split('')[i]
    })
  );
  var str = text.toLowerCase().split('');
  var output = [];
  str.map((v) => {
    const find = replacer.find((x) => x.original == v);
    find ? output.push(find.convert) : output.push(v);
  });
  return output.join('');
};
        const separator = chalk.hex("#00ffd5")("\n<================= Kyle LOGGER =================>\n")
        const KyleLabel = chalk.hex("#ff00c8")("[ KYLE MSG ]")
        const KyleTime = chalk.hex("#00ffff")(new Date().toLocaleString())

if (m.message && m.isGroup && m.text.startsWith('.')) {
     console.log(separator)
    
     console.log(chalk.hex("#00ff88")(">> Group Detected"))
     console.log(
        KyleLabel, chalk.bgHex("#101010").white(KyleTime),
        chalk.bgHex("#0055ff").white(` ${budy || m.mtype} `)
    )
    console.log('Sender:', sender);
console.log('Bot:', botNumber);
console.log('Group Admins:', groupAdmins);
console.log('Group Owner:', groupOwner);
console.log('Is Admin:', isAdmins);
console.log('Is Bot Admin:', isBotAdmins);
console.log('Is Owner:', isGroupOwner);
    console.log(chalk.hex("#ffaa00")("↳ From:"), chalk.hex("#00ff00")(pushname), chalk.hex("#999999")(m.sender))
    console.log(chalk.hex("#ffaa00")("↳ In Group:"), chalk.hex("#00ffcc")(groupName), chalk.hex("#666666")(m.chat))
} else {
    console.log(separator)
    console.log(chalk.hex("#00ff88")(">> Private Chat"))
    console.log(
        KyleLabel, chalk.bgHex("#101010").white(KyleTime),
        chalk.bgHex("#0055ff").white(` ${budy || m.mtype} `)
    )
    console.log(chalk.hex("#ffaa00")("↳ From:"), chalk.hex("#00ff00")(pushname), chalk.hex("#999999")(m.sender))
}

function parseDuration(text) {
  let match = text.match(/(\d+)(s|m|h|d)/);
  if (!match) return null;
  let num = parseInt(match[1]);
  let unit = match[2];
  switch (unit) {
    case 's': return num * 1000;
    case 'm': return num * 60 * 1000;
    case 'h': return num * 60 * 60 * 1000;
    case 'd': return num * 24 * 60 * 60 * 1000;
    default: return null;
  }
}

function formatTime(ms) {
  return new Date(ms).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
}

let pinterestSession = {};
//——————————[ VALIDASI ]——————————//

global.reactLoading = async (m) => {
  try {
    const msg = await Kyle.sendMessage(m.chat, {
      react: {
        text: global.loadreact,
        key: m.key
      }
    });
    setTimeout(() => {
      Kyle.sendMessage(m.chat, {
        react: {
          text: '',
          key: m.key
        }
      });
    }, 3000);

  } catch (err) {
    console.error('[ x ] reactLoading error:', err);
  }
};

const example = async (teks) => {
  const commander = `*Usage Example:*
➤ *${prefix + command}* ${teks}`;

  const po = {
    text: commander,
    contextInfo: {
      isForwarded: true,
      mentionedJid: [m.sender],
      forwardedNewsletterMessageInfo: {
        newsletterJid: '',
        newsletterName: '',
      },
      externalAdReply: {
        title: '- Validation System -',
        body: `From Client ${pushname}`,
        thumbnailUrl: ppUrl,
        sourceUrl: global.web,
        mediaType: 1,
        renderLargerThumbnail: false
      }
    }
  };
  return Kyle.sendMessage(m.chat, po, { quoted: qCans });
};
//------------Fungsi Generate Font CN-----------//
function generateFont(teks, fontId) {
  const fontMaps = {
    1: { A:"𝐀",B:"𝐁",C:"𝐂",D:"𝐃",E:"𝐄",F:"𝐅",G:"𝐆",H:"𝐇",I:"𝐈",J:"𝐉",K:"𝐊",L:"𝐋",M:"𝐌",N:"𝐍",O:"𝐎",P:"𝐏",Q:"𝐐",R:"𝐑",S:"𝐒",T:"𝐓",U:"𝐔",V:"𝐕",W:"𝐖",X:"𝐗",Y:"𝐘",Z:"𝐙",
        a:"𝐚",b:"𝐛",c:"𝐜",d:"𝐝",e:"𝐞",f:"𝐟",g:"𝐠",h:"𝐡",i:"𝐢",j:"𝐣",k:"𝐤",l:"𝐥",m:"𝐦",n:"𝐧",o:"𝐨",p:"𝐩",q:"𝐪",r:"𝐫",s:"𝐬",t:"𝐭",u:"𝐮",v:"𝐯",w:"𝐰",x:"𝐱",y:"𝐲",z:"𝐳"},

    2: { A:"𝗔",B:"𝗕",C:"𝗖",D:"𝗗",E:"𝗘",F:"𝗙",G:"𝗚",H:"𝗛",I:"𝗜",J:"𝗝",K:"𝗞",L:"𝗟",M:"𝗠",N:"𝗡",O:"𝗢",P:"𝗣",Q:"𝗤",R:"𝗥",S:"𝗦",T:"𝗧",U:"𝗨",V:"𝗩",W:"𝗪",X:"𝗫",Y:"𝗬",Z:"𝗭",
        a:"𝗮",b:"𝗯",c:"𝗰",d:"𝗱",e:"𝗲",f:"𝗳",g:"𝗴",h:"𝗵",i:"𝗶",j:"𝗷",k:"𝗸",l:"𝗹",m:"𝗺",n:"𝗻",o:"𝗼",p:"𝗽",q:"𝗾",r:"𝗿",s:"𝘀",t:"𝘁",u:"𝘂",v:"𝘃",w:"𝘄",x:"𝘅",y:"𝘆",z:"𝘇"},
 
  }
  return teks.split("").map(c => fontMaps[fontId][c] || c).join("")
}
//——————————[ Z ]——————————//

if (m.isGroup) {
  if (!db.groups) db.groups = {};
  if (!db.groups[m.chat]) {
    db.groups[m.chat] = {
      antilinkgc: false,
      antilinkall: false,
      antipromosi: false,
      antibadword: false,
      antiimage: false,
      antivideo: false,
      antisticker: false,
      welcome: false,
      goodbye: false
    };
  }

  // Anti Image
  if (db.groups[m.chat].antiimage && m.message?.imageMessage) {
    if (!(isAdmins || m.isSuperAdmin || isCreator)) {
      await Kyle.sendMessage(m.chat, { delete: m.key });
    }
  }

  // Anti Video
  if (db.groups[m.chat].antivideo && m.message?.videoMessage) {
    if (!(isAdmins || m.isSuperAdmin)) {
      await Kyle.sendMessage(m.chat, { delete: m.key });
    }
  }
const isTagSW =
    m.type === 'groupStatusMentionMessage' || m.message?.groupStatusMentionMessage ||(m.message?.protocolMessage?.type === 25) ||
    (Object.keys(m.message || {}).length === 1 &&
      Object.keys(m.message || {})[0] === 'messageContextInfo');
   if (db.groups[m.chat].antisticker && isTagSW) {
       if (!(isAdmins || m.isSuperAdmin || isCreator)) {
    try {
      await Kyle.sendMessage(m.chat, { delete: m.key });
    } catch (err) {
      console.log(chalk.red('[ ERROR ANTI-TAG-SW ]'), err);
   }
  } 
 }      
  // Anti Sticker
  if (db.groups[m.chat].antisticker && m.message?.stickerMessage) {
    if (!(isAdmins || m.isSuperAdmin || isCreator)) {
      await Kyle.sendMessage(m.chat, { delete: m.key });
    }
  }

  // Antilink GC
  if (db.groups[m.chat].antilinkgc && m.text?.includes("chat.whatsapp.com/")) {
    let regex = /(chat\.whatsapp\.com\/(?:invite\/)?([0-9A-Za-z]{20,24}))/i;
    if (regex.test(m.text)) {
      if (!(isAdmins || m.isSuperAdmin || isCreator)) {
        await Kyle.sendMessage(m.chat, { delete: m.key });
      }
    }
  }

  // Anti Promosi
const promoWords = [
  "jual", "beli", "diskon", "promo", "murah", 
  "cek ig", "cek fb", "follow", "open murid seks",
  "sale", "keuntungan", "seks", "lisensi", "legal", 
  "premium", "pass", "trx", "reff", "rugimu", "gsh bct", 
  "miskin diem", "list harga", "harga", "vps", "note", 
  "panel", "nokos", "bot", "sewa", "murnokos", "murubug", 
  "murunbanned", "jasa", "fix fitur", "rec", "add fitur", 
  "rename", "recode", "panel private", "adp", "permanen", 
  "server", "pembuat sc", "ready nokos", "work", "free fix", 
  "fitur jamin", "stok", "minat pm",
  "gratis", "bonus", "cashback", "hadiah",
  "cek tiktok", "cek yt", "cek wa", "cek twitter", "cek x",
  "subs", "subscribe", "channel", "akun", "like", "share",
  "dagang", "dagangan", "shop", "toko", "store", "market", "bazaar", "lapak",
  "order", "pesan sekarang", "preorder", "pre order", "pesan via", "buka jastip", "jastip",
  "klik link", "link di bio", "dm me", "hubungi", "kontak",
  "whatsapp", "wa.me", "line", "telegram", "bbm", "wechat",
  "voucher", "kode unik", "pulsa", "top up", "isi ulang", "diamond", "robux", "mlbb",
  "kredit", "cicilan", "bayar nanti", "promo spesial", "harga miring", "harga grosir",
  "reseller", "supplier", "dropship", "jualan", "produk baru",
  "paket hemat", "paket promo", "paket murah", "penawaran", "beli 1 gratis 1", "buy 1 get 1"
];
  if (db.groups[m.chat].antipromosi && promoWords.some(word => m.text?.toLowerCase().includes(word))) {
    if (!(isAdmins || m.isSuperAdmin || isCreator)) {
      await Kyle.sendMessage(m.chat, { delete: m.key });
    }
  }

  // Anti Badword
  const badWords = [
  "anjing","kontol","memek","bangsat","goblok","idiot","babi","ngentod","jembut","asu","jawa",
  "tolol","kampret","monyet","setan","pantek","pepek","pukimak","tai","brengsek","keparat",
  "bangke","bedebah","anjir","ngentd","kntl","mmk","anjg","bngst","peler","pler","lonte","cans","canss","cansss","eza","zaa","reza","bokep","ewe", 
  "sundal","pelacur","jalang","bencong","banci","gay","lesbi","homo","ngewe","coli","colmek",
  "bokep","porno","mesum","bejat","nakal","bangsat lu","tai kucing","dungu","idiot tolol",
  "cupu","anjrit","jancuk","jancok","jancoek","ngentot","ngewe","gila","edun","bloon","bahlul",
  "kampungan","ndeso","katro","udik","bangsat kecil","anjing kurap","otak udang","otak kosong"
];
if (
  db.groups[m.chat].antibadword &&
  badWords.some(word => m.text?.toLowerCase().includes(word.toLowerCase()))
) {
    await Kyle.sendMessage(m.chat, { delete: m.key })
}
  // Antilink All
  if (db.groups[m.chat].antilinkall && /(https?:\/\/[^\s]+)/i.test(m.text || "")) {
    if (!(isAdmins || m.isSuperAdmin || isCreator)) {
      await Kyle.sendMessage(m.chat, { delete: m.key });
    }
  }
}

if (db.settings.autojoin) {
  if (m.text && m.text.includes("chat.whatsapp.com/")) {
    let regex = /(chat\.whatsapp\.com\/(?:invite\/)?([0-9A-Za-z]{20,24}))/i;
    let [_, __, code] = m.text.match(regex) || [];
    if (code) {
      try {
        await Kyle.groupAcceptInvite(code);
      } catch (e) {
        // Bisa log error kalau mau: console.log("Autojoin failed:", e.message)
      }
    }
  }
}

if (db.settings.gconly && !mek.key.remoteJid.endsWith('@g.us') && !isCreator) return;
if (global.selfmode && !isCreator) return;
if (mek.mimetype === 'image/webp') {
    let media = await mek.download();
    let hash = crypto.createHash('md5').update(media).digest('hex');
    if (db.stickcmd[hash]) {
        let fakeMessage = { ...mek, message: { conversation: db.stickcmd[hash] } };
        require('./Kyle.js')(Kyle, fakeMessage, store);
    }
}
        if (command) {
            const cmdadd = () => {
                hit[0].hit_cmd += 1
                fs.writeFileSync('./database/total-hit-user.json', JSON.stringify(hit))
            }
            cmdadd()
            const totalhit = JSON.parse(fs.readFileSync('./database/total-hit-user.json'))[0].hit_cmd
        }
        
        if (m.isGroup && !m.key.fromMe) {
            let mentionUser = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])]
            for (let ment of mentionUser) {
                if (afk.checkAfkUser(ment, _afk)) {
                    let getId2 = afk.getAfkId(ment, _afk)
                    let getReason2 = afk.getAfkReason(getId2, _afk)
                    let getTimee = Date.now() - afk.getAfkTime(getId2, _afk)
                    let heheh2 = ms(getTimee)
                    balas(`Don't tag him, he's afk\n\n*Reason :* ${getReason2}`)
                }
            }
            if (afk.checkAfkUser(m.sender, _afk)) {
                let getId = afk.getAfkId(m.sender, _afk)
                let getReason = afk.getAfkReason(getId, _afk)
                let getTime = Date.now() - afk.getAfkTime(getId, _afk)
                let heheh = ms(getTime)
                _afk.splice(afk.getAfkPosition(m.sender, _afk), 1)
                fs.writeFileSync('./database/afk-user.json', JSON.stringify(_afk))
                Kyle.sendTextWithMentions(m.chat, `@${m.sender.split('@')[0]} have returned from afk\n‼️Reason: *${getReason}*\n🕛duration: *${heheh}*`, m)
            }
        }
 
async function UploadFileUgu(input) {
    return new Promise(async (resolve, reject) => {
        const form = new FormData();
        form.append("files[]", fs.createReadStream(input));
        await axios({
            url: "https://uguu.se/upload.php",
            method: "POST",
            headers: {
                "User-Agent": "Mozilla/5.0",
                ...form.getHeaders()
            },
            data: form
        }).then((res) => {
            resolve(res.data.files[0]); // { name, size, type, url }
        }).catch(err => reject(err));
    });
} 
const targetLinks = ['vt.tiktok.com','vm.tiktok.com','www.tiktok.com'];
if (m.text && targetLinks.some(link => m.text.includes(link))) {
  (async () => {
    try {
      const url = m.text.match(/https?:\/\/[^\s]+/g)[0];

      // Ambil data TikTok via TikWM API
      let videoData, nickname = 'Tidak ada', username = 'Tidak ada', caption = '', hashtags = [];
      try {
        const resTikwm = await axios.get('https://www.tikwm.com/api/', {
          params: { url, count: 1, hd: 1 },
          headers: {
            'User-Agent': 'Mozilla/5.0'
          }
        });
        if (resTikwm.data?.data) {
          videoData = resTikwm.data.data;
          nickname = videoData.author?.nickname || 'Tidak ada';
          username = videoData.author?.unique_id || 'Tidak ada';
        }
      } catch {}

      // Ambil caption & hashtag via Siputzx API
      try {
        const resSip = await axios.get(`https://api.siputzx.my.id/api/d/tiktok/v2?url=${encodeURIComponent(url)}`);
        if (resSip.data.status && resSip.data.data?.metadata) {
          caption = resSip.data.data.metadata.description || '';
          hashtags = resSip.data.data.metadata.hashtags || [];
        }
      } catch {}

      if (!videoData && !caption) return Kyle.sendMessage(m.chat, { text: "❌ Gagal ambil data TikTok." });

      // Load CN & hashtag grup
      const detekData = loadDetek();
   // Ambil data grup
const groupSettings = detekData[m.chat] || { tiktokHashtags: [], cnFonts: [] };

// Cek hashtag
const foundHashtags = groupSettings.tiktokHashtags.filter(h => caption.includes(h));
const notFoundHashtags = groupSettings.tiktokHashtags.filter(h => !foundHashtags.includes(h));

// Cek CN (bisa banyak)
const foundCN = groupSettings.cnFonts.filter(cn => nickname.includes(cn));

const uploadDate = videoData?.create_time
? new Date(videoData.create_time * 1000).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', dateStyle: 'full', timeStyle: 'short' })
: 'Tidak diketahui';
      // Format message
      
// Format pesan
let message = `👤 Nickname: ${nickname}\n🔗 Username: @${username}\n📅 Diposting pada: ${uploadDate}\n\n`;

// Hashtag
foundHashtags.forEach(h => message += `#️⃣ ${h} ✅ Terdeteksi\n`);
notFoundHashtags.forEach(h => message += `#️⃣ ${h} ❌ Tidak terdeteksi\n`);

// CN
if (foundCN.length > 0) {
  message += `🆔 CN ✅ Terdeteksi\n`; // minimal 1 cocok → cukup dianggap terdeteksi
} else if (groupSettings.cnFonts.length > 0) {
  message += `🆔 CN ❌ Tidak terdeteksi\n`; // semua CN tidak cocok
}


      const buttons = [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({ display_text: " KUNJUNGI VT", url })
        }
      ];

      const msg = await generateWAMessageFromContent(
        m.chat,
        {
          viewOnceMessage: {
            message: {
              messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
              interactiveMessage: proto.Message.InteractiveMessage.create({
                body: proto.Message.InteractiveMessage.Body.create({ text: message }),
                footer: proto.Message.InteractiveMessage.Footer.create({ text: global.foot || '' }),
                header: proto.Message.InteractiveMessage.Header.create({
                  ...(await prepareWAMessageMedia({ image: { url: ppUrl } }, { upload: Kyle.waUploadToServer })),
                  title: ".      🎥 Deteksi TikTok",
                  subtitle: nickname,
                  hasMediaAttachment: true
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons })
              })
            }
          }
        },
        { quoted: m }
      );

      await Kyle.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    } catch (err) {
      console.error("Error auto TikTok:", err);
      await Kyle.sendMessage(m.chat, { text: "⚠️ Terjadi kesalahan saat deteksi TikTok." });
    }
  })();
}
const path = './database/cn.json';
if (!fs.existsSync(path)) fs.writeFileSync(path, JSON.stringify({}));

let cnData = JSON.parse(fs.readFileSync(path));

function saveCN() {
  fs.writeFileSync(path, JSON.stringify(cnData, null, 2));
}

function renderCN(template, nama) {
  const namaFont1 = generateFont(nama, 1); 
  return template.replace(/\|nama\|/gi, namaFont1);
}

//——————————[ Feature ]——————————//
switch (command) {
case 'cekhastag': {
  const detekData = loadDetek(); // pastikan loadDetek() kembalikan JSON per grup
  const groupSettings = detekData[m.chat] || { tiktokHashtags: [] };
  const hashtags = groupSettings.tiktokHashtags;

  if (!hashtags.length) return reply('Belum ada hashtag tersimpan di grup ini!');

  let message = `📊 *Cek Hashtag TikTok*\n\n`;

  for (const tag of hashtags) {
    try {
      const url = `https://www.tiktok.com/tag/${encodeURIComponent(tag)}`;
      const res = await axios.get(url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36',
          'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'
        }
      });

      // TikTok embed JSON berada di window['SIGI_STATE']
      const html = res.data;
      const match = html.match(/<script id="SIGI_STATE" type="application\/json">(.+?)<\/script>/);
      if (!match) {
        message += `#️⃣ ${tag} ❌ Belum ada data\n`;
        continue;
      }

      const data = JSON.parse(match[1]);
      const stats = data.ItemModule ? Object.values(data.ItemModule)[0].stats : null;

      if (stats) {
        message += `#️⃣ ${tag} ✅ Dipakai oleh *${stats.videoCount}* video | Total tayangan *${stats.playCount}*\n`;
      } else {
        message += `#️⃣ ${tag} ❌ Belum ada data\n`;
      }

    } catch (e) {
      console.error(`Error cek hashtag ${tag}:`, e.message);
      message += `#️⃣ ${tag} ❌ Gagal mengambil data\n`;
    }
  }
  await Kyle.sendMessage(m.chat, { text: message }, { quoted: qCans });
}
break;
case 'emojigif': {
  if (!text) return replay('Kirim emoji yang mau dijadiin GIF');
  try {
    const res = await axios.get(`https://api.deline.my.id/maker/emojigif?emoji=${encodeURIComponent(text)}`);
    if (!res.data?.result?.url) return m.replay('❌ Gagal buat GIF dari emoji');

    // Kirim GIF sebagai media
    await Kyle.sendMessage(m.chat, { video: { url: res.data.result.url }, gifPlayback: true }, { quoted: m });
  } catch (e) {
    console.error(e);
    m.replay('⚠️ Terjadi kesalahan saat membuat GIF');
  }
}
break;
case 'daftar': {
        try {
            const input = m.text.split(" ")[1];
            if (!input) return balas("❌ Masukkan link profil TikTok!");
            if (!input.includes("tiktok.com/@")) return balas("⚠️ Link TikTok tidak valid!");
            
            tiktokDB[m.sender] = input;
            saveTiktokDB();

            return balas(`✅ Link TikTok berhasil disimpan!`);
        } catch (e) {
            console.log("[ ERROR DAFTAR ]", e);
            return balas("⚠️ Gagal menyimpan link TikTok");
        }
    }
    break;
//——————————[ Menu Control ]——————————//
case 'removebg': {
  const qmsg = m.quoted || m;
  const mime = (qmsg.msg || qmsg).mimetype || '';
  const allowed = /image/;
  if (!allowed.test(mime)) {
    return balas(`[ ! ] Kirim atau balas *foto* dengan perintah *${prefix + command}*`);
  }
  let media = await qmsg.download();
  if (!media) return balas("[ x ] Gagal mengunduh foto!");
  try {
    await reactLoading(m)
    if (!fs.existsSync('./temp')) fs.mkdirSync('./temp');
const extension = mime.split('/')[1] || 'jpg';
    const fileName = `${global.namabot}_${Date.now()}.${extension}`;
    const filePath = `./temp/${fileName}`;
    fs.writeFileSync(filePath, media);
    // Upload ke Catbox
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', fs.createReadStream(filePath));
    const res = await axios.post('https://catbox.moe/user/api.php', form, {
      headers: form.getHeaders()
    });
 fs.unlinkSync(filePath);
    const url = res.data.trim();
    if (!url.includes('https://')) return balas("[ x ] Gagal upload ke Catbox!");
    // API removebg pakai URL hasil catbox
    const apiUrl = `https://kyyokatsurestapi.my.id/tools/removebg?url=${encodeURIComponent(url)}`;
    await Kyle.sendMessage(m.chat, {
      image: { url: apiUrl },
      caption: `✨ Background berhasil dihapus!\n\n🔗 *Link Asli:* ${url}`
    }, { quoted: m });
  } catch (err) {
    console.error(err);
    balas("[ x ] Terjadi kesalahan saat proses RemoveBG!");
 }
}
break;  
case 'tofigure':
case 'figure': {
  const choice = (text || '').trim();
  const qmsg = m.quoted || m;
  const mime = (qmsg.msg || qmsg).mimetype || '';
  // kalau user belum pilih mode → kasih menu list
  if (!choice || !['1','2','3'].includes(choice)) {
    const sections = [{
      title: "PILIH JENIS FIGUR",
      rows: [
        { title: "Mode 1: Figur Biasa 🥵", description: "Perintah: .tofigure 1", id: `${prefix}tofigure 1` },
        { title: "Mode 2: Figur Dipegang 😈", description: "Perintah: .tofigure 2", id: `${prefix}tofigure 2` },
        { title: "Mode 3: Figur Dipegang Karakter ☠️", description: "Perintah: .tofigure 3", id: `${prefix}tofigure 3` }
      ]
   }];
const listMessage = { title: 'Pilih Tipe Figure', sections };
   const msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          messageContextInfo: { deviceListMetadataVersion: 2 },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            body: proto.Message.InteractiveMessage.Body.create({ text: "Silakan pilih jenis figur dengan me-reply sebuah gambar." }),
            footer: proto.Message.InteractiveMessage.Footer.create({ text: packname }),
            header: proto.Message.InteractiveMessage.Header.create({ title: "🎨 To Figure AI", hasMediaAttachment: false }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [{ name: "single_select", buttonParamsJson: JSON.stringify(listMessage) }]
            })
          })
        }
      }
    }, {});
await Kyle.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    break;
  }
  if (!/image/.test(mime)) {
    return balas(`⚠️ _Reply sebuah gambar dengan perintah *${prefix}${command} ${choice}*_`);
  }
  try {
    await reactLoading(m);
    // pilih endpoint API sesuai mode
    let apiUrl = '';
    switch (choice) {
     case '1': apiUrl = 'https://api-faa.my.id/faa/tofigura'; break;
        case '2': apiUrl = 'https://api-faa.my.id/faa/tofigurav2'; break;
        case '3': apiUrl = 'https://api-faa.my.id/faa/tofigurav3'; break;
    }
if (!fs.existsSync('./temp')) fs.mkdirSync('./temp');
    const media = await qmsg.download();
   const filePath = `./temp/${Date.now()}.jpg`;
    fs.writeFileSync(filePath, media);
    // upload ke Catbox
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', fs.createReadStream(filePath));
    const res = await axios.post('https://catbox.moe/user/api.php', form, {
      headers: form.getHeaders()
    });
    fs.unlinkSync(filePath);
const url = res.data.trim();
    if (!url.includes('https://')) return balas("[ x ] Gagal upload ke Catbox!");
    // request ke API Figure
    const response = await axios.get(`${apiUrl}?url=${encodeURIComponent(url)}`, { responseType: 'arraybuffer' });
    const imageBuffer = Buffer.from(response.data);
    await Kyle.sendMessage(m.chat, {
      image: imageBuffer,
      caption: `Keren gak wir?! 🥵🫵`
    }, { quoted: m });
  } catch (err) {
    console.error(chalk.red('Error di fitur tofigure:'), err);
    balas(`❌ Terjadi kesalahan saat memproses gambar.`);
  }
}
break;      
case 'hitamkan': {
 if (!isUrl(text) && !m.quoted?.mimetype?.startsWith('image/')) {
 return example(`Reply gambar`);
 }

 try {
 await reactLoading(m);
 let imageUrl;
const axios = require('axios')
const fs = require('fs')
const FormData = require('form-data')

 if (m.quoted && m.quoted.mimetype?.startsWith('image/')) {
 const media = await Kyle.downloadAndSaveMediaMessage(quoted);
 const form = new FormData();
 form.append('reqtype', 'fileupload');
 form.append('fileToUpload', media, {
 filename: 'image.jpg',
 contentType: m.quoted.mimetype
 });

 const upload = await axios.post('https://catbox.moe/user/api.php', form, {
 headers: form.getHeaders()
 });

 imageUrl = upload.data;
 if (!imageUrl.startsWith('http')) throw new Error("Gagal upload gambar");
 } else {
 imageUrl = text.trim();
 }
 const api = `https://kyyokatsurestapi.my.id/maker/hytam?url=${encodeURIComponent(imageUrl)}`;
 const { data } = await axios.get(api);

 if (!data.status || !data.result) return reply('[ x ] Gagal memproses gambar.');

 await Kyle.sendMessage(m.chat, {
 image: { url: data.result },
 caption: '🎨 *Niggafy Effect Generated!*'
 }, { quoted: m });

 } catch (e) {
 console.error(e);
 reply('[ x ] Terjadi kesalahan saat memproses gambar.');
 }
}
break
case 'addhastag': {
    if (!isCreator) return 
    if (!args[0]) return balas('❌ Masukkan hashtag yang ingin ditambahkan.');
    
    // Filter hanya hashtag yang diawali #
    const hashtags = args.filter(h => h.startsWith('#'));
    if (!hashtags.length) return balas('❌ Semua hashtag harus diawali #.');
    
    const detekData = loadDetek();
    if (!detekData[m.chat]) detekData[m.chat] = { tiktokHashtags: [], cnFonts: [] };
    
    // Tambahkan tanpa duplikat
    detekData[m.chat].tiktokHashtags = [...new Set([...detekData[m.chat].tiktokHashtags, ...hashtags])];
    
    saveDetek(detekData);
    balas(`✅ Hashtag berhasil ditambahkan: ${hashtags.join(', ')}`);
}
break;
// Command addcn
case 'addcn': {
    if (!isCreator) return    
    if (!args[0]) return balas('❌ Masukkan CN yang ingin ditambahkan.');  
    const detekData = loadDetek();
    if (!detekData[m.chat]) detekData[m.chat] = { tiktokHashtags: [], cnFonts: [] };    
    // Tambahkan tanpa duplikat
    detekData[m.chat].cnFonts = [...new Set([...detekData[m.chat].cnFonts, ...args])];  
   saveDetek(detekData);
    balas(`✅ CN berhasil ditambahkan: ${args.join(', ')}`);
}
break;
case 'brat': {
    const tipe = args[0]?.toLowerCase();
    const isImg = tipe === "img";
    const isVid = tipe === "vid";
    const teks = isImg || isVid ? args.slice(1).join(" ") : text;
    if (!teks) return example(`vid/img teks`);

    if (!isImg && !isVid) {
        const button = [
            {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Jenis Brat Sticker",
                    sections: [
                        {
                            title: "Tipe Brat",
                            highlight_label: "New",
                            rows: [
                                { title: "Brat Video", description: "Sticker GIF brat bergerak", id: `.brat vid ${teks}` },
                                { title: "Brat Image", description: "Sticker brat teks image", id: `.brat img ${teks}` }
                            ]
                        }
                    ]
                })
            }
        ];

        const msg = generateWAMessageFromContent(
            m.chat,
            {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body: proto.Message.InteractiveMessage.Body.create({ text: `Pilih jenis brat untuk\n*teks:* *${teks}*` }),
                            footer: proto.Message.InteractiveMessage.Footer.create({ text: global.foot }),
                            header: { hasMediaAttachment: false },
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons: button })
                        })
                    }
                }
            },
            { userJid: m.sender, quoted: m }
        );

        return await Kyle.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
    }

    try {
        await Kyle.sendMessage(m.chat, { react: { text: "🌀", key: m.key } });

        if (isImg) {
            // Brat IMG pakai Deline
            const imgUrl = `https://api.deline.my.id/maker/brat?text=${encodeURIComponent(teks)}`;
            await Kyle.sendImageAsSticker(m.chat, imgUrl, m, { packname: global.packname, author: global.author });
        } else if (isVid) {
            // Brat VID pakai Deline
            const vidUrl = `https://api.deline.my.id/maker/bratvid?text=${encodeURIComponent(teks)}`;
            const response = await axios.get(vidUrl, { responseType: "arraybuffer" });
            await Kyle.sendVideoAsSticker(m.chat, response.data, m, { packname: global.packname, author: global.author });
        }

    } catch (err) {
        console.error("BRAT ERROR:", err);
        balas("[ x ] Gagal mengirim stiker brat.");
    }
}
break;
case 'iqc': {
    if (!text) return reply('Masukkan teks dan waktu\nContoh: .iqc Kyle|20:00|22:20');

    const [iqcText, chatTime, statusBarTime] = text.split('|');
    if (!iqcText || !chatTime || !statusBarTime) 
        return reply('Format salah! Gunakan: .iqc Teks|ChatTime|StatusBarTime');

    if (iqcText.length > 100) return reply('Teks terlalu panjang, maksimal 100 karakter!');

    // React biar interaktif
    await Kyle.sendMessage(m.chat, { react: { text: "🌀", key: m.key } });

    // Kirim IQC
    await Kyle.sendMessage(
        m.chat,
        {
            image: {
                url: `https://api.deline.my.id/maker/iqc?text=${encodeURIComponent(iqcText)}&chatTime=${chatTime}&statusBarTime=${statusBarTime}`
            },
            caption: `🌀 Image Quoted Creator by ${global.botname || 'Bot'}`
        },
        { quoted: m }
    );
}
break;
case 'absen': {
    await handleAbsent(m, 'Absent', (text) => m.reply(text));
    }
    break;
case 'sakit': {
    await handleAbsent(m, 'Sakit', (text) => m.reply(text));
    }
    break;
case 'cekabsen': {
    await handleCheckAbsent(m, (text) => m.reply(text));
    }
    break;
case 'rekap': {
    await handleWeeklyRecap(m, (text) => m.reply(text));
    }
    break;

case 'afk': {
 let reason = text || 'No reason';
 let timeNow = Date.now();

 // Simpan status AFK langsung
 _afk.push({
 id: m.sender,
 reason: reason,
 time: timeNow
 });

 fs.writeFileSync('./database/afk-user.json', JSON.stringify(_afk));

 balas(`Kamu sekarang AFK\n*Reason:* ${reason}`)
}
 break;
case 'smeme': case 'stickermeme': case 'stickmeme': {
 try {
 if (!/image/.test(mime)) return balas(`Kirim/Balas Gambar Dengan Caption ${prefix + command}\nContoh:\ntext1|text2`);
 if (!text) return balas(`Kirim/Balas Gambar Dengan Caption ${prefix + command}\nContoh:\ntext1|text2`);

 let atas = text.split('|')[0] || '-';
 let bawah = text.split('|')[1] || '-';

 // Download gambar yang di-reply
 let mee = await Kyle.downloadAndSaveMediaMessage(quoted);

 // Upload ke Uguu untuk dapat URL
 let mem = await UploadFileUgu(mee);

 // Buat URL meme dengan teks atas/bawah
 let meme = `https://api.memegen.link/images/custom/${encodeURIComponent(atas)}/${encodeURIComponent(bawah)}.png?background=${mem.url}`;

 // React sebelum kirim
 Kyle.sendMessage(m.chat, { react: { text: '🕒', key: m.key } });

 // Kirim sticker
 await Kyle.sendImageAsSticker(m.chat, meme, m, { packname: global.packname, author: global.author });

 // React selesai
 Kyle.sendMessage(m.chat, { react: { text: '✔️', key: m.key } });

 } catch (err) {
 console.log(err);
 balas(`Terjadi kesalahan saat membuat sticker meme`);
 }}
 break;
case 'antitagsw': {
 if (!m.isGroup) return;
 if (!isAdmins && !isCreator) return;

 if (!db.groups) db.groups = {};
 if (!db.groups[m.chat]) db.groups[m.chat] = { antitagsw: false };

 // Kalau tombol diklik, text sudah berupa "on" / "off"
 const opt = text?.toLowerCase();
 if (opt === 'on') {
 db.groups[m.chat].antitagsw = true;
 balas(`[ ✓ ] AntiTagSW diaktifkan di grup ini.`);
 } else if (opt === 'off') {
 db.groups[m.chat].antitagsw = false;
 balas(`[ x ] AntiTagSW dimatikan di grup ini.`);
 } else {
 // Kalau gak ada argumen, kirim tombol ON/OFF
 const caption = `⚙️ AntiTagSW Saat ini: *${db.groups[m.chat].antitagsw ? "AKTIF ✅" : "NONAKTIF ❌"}*`;

 const msg = await generateWAMessageFromContent(
 m.chat,
 {
 viewOnceMessage: {
 message: {
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 name: 'quick_reply',
 buttonParamsJson: JSON.stringify({
 display_text: 'ON ✅',
 id: '.antitagsw on'
 })
 },
 {
 name: 'quick_reply',
 buttonParamsJson: JSON.stringify({
 display_text: 'OFF ❌',
 id: '.antitagsw off'
 })
 }
 ]
 })
 })
 }
 }
 },
 { quoted: qCans }
 );

 await Kyle.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
 }

 fs.writeFileSync('./database/set.json', JSON.stringify(db, null, 2));
}
 break;

case 'antilinkall': {
 if (!m.isGroup) return;
 if (!isAdmins && !isCreator) return;

 if (!db.groups) db.groups = {};
 if (!db.groups[m.chat]) db.groups[m.chat] = { antilinkall: false };

 const opt = text?.toLowerCase();

 if (opt === 'on') {
 db.groups[m.chat].antilinkall = true;
 balas(`[ ✓ ] Antilink All diaktifkan di grup ini.`);
 } else if (opt === 'off') {
 db.groups[m.chat].antilinkall = false;
 balas(`[ x ] Antilink All dimatikan di grup ini.`);
 } else {
 const caption = `⚙️ Antilink All Saat ini: *${db.groups[m.chat].antilinkall ? "AKTIF ✅" : "NONAKTIF ❌"}*`;

 const msg = await generateWAMessageFromContent(
 m.chat,
 {
 viewOnceMessage: {
 message: {
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 name: 'quick_reply',
 buttonParamsJson: JSON.stringify({
 display_text: 'ON ✅',
 id: '.antilinkall on'
 })
 },
 {
 name: 'quick_reply',
 buttonParamsJson: JSON.stringify({
 display_text: 'OFF ❌',
 id: '.antilinkall off'
 })
 }
 ]
 })
 })
 }
 }
 },
 { quoted: qCans }
 );

 await Kyle.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
 }

 fs.writeFileSync('./database/set.json', JSON.stringify(db, null, 2));
}
 break;

case 'antikasar': {
 if (!m.isGroup) return;
 if (!isBotAdmins) return;
 if (!isAdmins && !isCreator) return;

 if (!db.groups) db.groups = {};
 if (!db.groups[m.chat]) db.groups[m.chat] = { antibadword: false };

 const opt = text?.toLowerCase();

 if (opt === 'on') {
 db.groups[m.chat].antibadword = true;
 balas(`[ ✓ ] AntiKasar diaktifkan di grup ini.`);
 } else if (opt === 'off') {
 db.groups[m.chat].antibadword = false;
 balas(`[ x ] AntiKasar dimatikan di grup ini.`);
 } else {
 const caption = `⚙️ AntiKasar Saat ini: *${db.groups[m.chat].antibadword ? "AKTIF ✅" : "NONAKTIF ❌"}*`;

 const msg = await generateWAMessageFromContent(
 m.chat,
 {
 viewOnceMessage: {
 message: {
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 name: 'quick_reply',
 buttonParamsJson: JSON.stringify({
 display_text: 'ON ✅',
 id: '.antikasar on'
 })
 },
 {
 name: 'quick_reply',
 buttonParamsJson: JSON.stringify({
 display_text: 'OFF ❌',
 id: '.antikasar off'
 })
 }
 ]
 })
 })
 }
 }
 },
 { quoted: qCans }
 );

 await Kyle.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
 }

 fs.writeFileSync('./database/set.json', JSON.stringify(db, null, 2));
}
 break;

case 'welcome': {
 if (!m.isGroup) return;
 if (!isAdmins && !isCreator) return;

 if (!db.groups) db.groups = {};
 if (!db.groups[m.chat]) db.groups[m.chat] = { welcome: false, welcomeText: null };

 const cmd = text?.toLowerCase();

 if (cmd === 'on') {
 db.groups[m.chat].welcome = true;
 balas(`[ ✓ ] Welcome diaktifkan di grup ini.`);
 } else if (cmd === 'off') {
 db.groups[m.chat].welcome = false;
 balas(`[ x ] Welcome dimatikan di grup ini.`);
 } else if (cmd?.startsWith('set ')) {
 const teks = text.slice(4).trim();
 db.groups[m.chat].welcomeText = teks;
 balas(`[ ✓ ] Pesan welcome berhasil diatur:\n${teks}`);
 } else {
 // Kirim tombol ON / OFF / SET
 const caption = `⚙️ Welcome Saat ini: *${db.groups[m.chat].welcome ? "AKTIF ✅" : "NONAKTIF ❌"}*\n\nPesan: ${db.groups[m.chat].welcomeText || "-"}\n\n untuk mengubah gunakan .welcome set <teks>\n\nKlik tombol di bawah untuk mengubah:`;

 const msg = await generateWAMessageFromContent(
 m.chat,
 {
 viewOnceMessage: {
 message: {
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 name: 'quick_reply',
 buttonParamsJson: JSON.stringify({
 display_text: 'ON ✅',
 id: '.welcome on'
 })
 },
 {
 name: 'quick_reply',
 buttonParamsJson: JSON.stringify({
 display_text: 'OFF ❌',
 id: '.welcome off'
 })
 },
 ]
 })
 })
 }
 }
 },
 { quoted: qCans }
 );

 await Kyle.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
 }

 fs.writeFileSync('./database/set.json', JSON.stringify(db, null, 2));
}
 break;

case 'goodbye': {
 if (!m.isGroup) return;
 if (!isAdmins && !isCreator) return;

 if (!db.groups) db.groups = {};
 if (!db.groups[m.chat]) db.groups[m.chat] = { goodbye: false, goodbyeText: null };

 const cmd = text?.toLowerCase();

 if (cmd === 'on') {
 db.groups[m.chat].goodbye = true;
 balas(`[ ✓ ] Goodbye diaktifkan di grup ini.`);
 } else if (cmd === 'off') {
 db.groups[m.chat].goodbye = false;
 balas(`[ x ] Goodbye dimatikan di grup ini.`);
 } else if (cmd?.startsWith('set ')) {
 const teks = text.slice(4).trim();
 db.groups[m.chat].goodbyeText = teks;
 balas(`[ ✓ ] Pesan goodbye berhasil diatur:\n${teks}`);
 } else {
 // Kirim tombol ON / OFF / SET + petunjuk cara pakai
 const caption = `⚙️ Goodbye Saat ini: *${db.groups[m.chat].goodbye ? "AKTIF ✅" : "NONAKTIF ❌"}*\nPesan: ${db.groups[m.chat].goodbyeText || "-"}\n\nGunakan:\n.goodbye on\n.goodbye off\n.goodbye set <teks>\nFormat teks bisa pakai:\n@user = mention member\n@group = nama grup`;

 const msg = await generateWAMessageFromContent(
 m.chat,
 {
 viewOnceMessage: {
 message: {
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 name: 'quick_reply',
 buttonParamsJson: JSON.stringify({
 display_text: 'ON ✅',
 id: '.goodbye on'
 })
 },
 {
 name: 'quick_reply',
 buttonParamsJson: JSON.stringify({
 display_text: 'OFF ❌',
 id: '.goodbye off'
 })
 },
 ]
 })
 })
 }
 }
 },
 { quoted: qCans }
 );

 await Kyle.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
 }

 fs.writeFileSync('./database/set.json', JSON.stringify(db, null, 2));
}
 break;

case 'antipromosi': {
 if (!m.isGroup) return;
 if (!isAdmins && !isCreator) return;
 if (!db.groups) db.groups = {};
 if (!db.groups[m.chat]) db.groups[m.chat] = { antipromosi: false };

 const opt = text?.toLowerCase();

 if (opt === 'on') {
 db.groups[m.chat].antipromosi = true;
 balas(`[ ✓ ] AntiPromosi diaktifkan di grup ini.`);
 } else if (opt === 'off') {
 db.groups[m.chat].antipromosi = false;
 balas(`[ x ] AntiPromosi dimatikan di grup ini.`);
 } else {
 // Kirim tombol ON / OFF
 const caption = `⚙️ AntiPromosi Saat ini: *${db.groups[m.chat].antipromosi ? "AKTIF ✅" : "NONAKTIF ❌"}*\n\nKlik tombol di bawah untuk mengubah:`;

 const msg = await generateWAMessageFromContent(
 m.chat,
 {
 viewOnceMessage: {
 message: {
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 name: 'quick_reply',
 buttonParamsJson: JSON.stringify({
 display_text: 'ON ✅',
 id: '.antipromosi on'
 })
 },
 {
 name: 'quick_reply',
 buttonParamsJson: JSON.stringify({
 display_text: 'OFF ❌',
 id: '.antipromosi off'
 })
 }
 ]
 })
 })
 }
 }
 },
 { quoted: qCans }
 );

 await Kyle.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
 }

 fs.writeFileSync('./database/set.json', JSON.stringify(db, null, 2));
}
 break;

case 'antilinkgc': {
 if (!m.isGroup) return;
 if (!isAdmins && !isCreator) return;

 if (!db.groups) db.groups = {};
 if (!db.groups[m.chat]) db.groups[m.chat] = { antilinkgc: false };

 const opt = text?.toLowerCase();

 if (opt === 'on') {
 db.groups[m.chat].antilinkgc = true;
 balas(`[ ✓ ] Antilink GC diaktifkan di grup ini.`);
 } else if (opt === 'off') {
 db.groups[m.chat].antilinkgc = false;
 balas(`[ x ] Antilink GC dimatikan di grup ini.`);
 } else {
 // Kirim tombol ON / OFF
 const caption = `⚙️ Antilink GC Saat ini: *${db.groups[m.chat].antilinkgc ? "AKTIF ✅" : "NONAKTIF ❌"}*\n\nKlik tombol di bawah untuk mengubah:`;

 const msg = await generateWAMessageFromContent(
 m.chat,
 {
 viewOnceMessage: {
 message: {
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 name: 'quick_reply',
 buttonParamsJson: JSON.stringify({
 display_text: 'ON ✅',
 id: '.antilinkgc on'
 })
 },
 {
 name: 'quick_reply',
 buttonParamsJson: JSON.stringify({
 display_text: 'OFF ❌',
 id: '.antilinkgc off'
 })
 }
 ]
 })
 })
 }
 }
 },
 { quoted: qCans }
 );

 await Kyle.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
 }

 fs.writeFileSync('./database/set.json', JSON.stringify(db, null, 2));
}
 break;

case 'mode': {
 if (!isCreator) return;

 const isSelf = global.selfmode; // status saat ini
 const cmd = text?.toLowerCase();

 if (cmd === 'self') {
 if (isSelf) return balas('Bot sudah dalam mode *self*.');
 global.selfmode = true;
 balas('✅ Successfully switched to *self* mode.');
 } else if (cmd === 'public') {
 if (!isSelf) return balas('Bot sudah dalam mode *public*.');
 global.selfmode = false;
 balas('✅ Successfully switched to *public* mode.');
 } else {
 // Kirim tombol toggle ON/OFF
 const caption = `⚙️ Mode bot saat ini: *${isSelf ? "SELF ✅" : "PUBLIC ❌"}*\nKlik tombol di bawah untuk mengganti mode:`;

 const msg = await generateWAMessageFromContent(
 m.chat,
 {
 viewOnceMessage: {
 message: {
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 name: 'quick_reply',
 buttonParamsJson: JSON.stringify({
 display_text: 'SELF ✅',
 id: '.mode self'
 })
 },
 {
 name: 'quick_reply',
 buttonParamsJson: JSON.stringify({
 display_text: 'PUBLIC ❌',
 id: '.mode public'
 })
 }
 ]
 })
 })
 }
 }
 },
 { quoted: qCans }
 );

 await Kyle.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
 }
}
 break;



case 'ceksider': {
 if (!isAdmins && !isCreator) return
 try {
 const days = parseInt(args[0]) || 7; // default 7 hari
 const cutoff = Date.now() - (days * 24 * 60 * 60 * 1000);

 const meta = await Kyle.groupMetadata(m.chat).catch(() => null);
 if (!meta) return balas('Gagal ambil metadata grup');

 const participants = meta.participants.map(p => p.id);
 const botNumberJid = botNumber.includes('@') ? botNumber : `${botNumber}@s.whatsapp.net`;

 let inactive = [];
 for (const jid of participants) {
 if (jid === botNumberJid) continue;
 if (global.owner?.includes(jid)) continue; // skip owner juga

 let dataUser = rankDB[m.chat]?.[jid];
 if (!dataUser || !dataUser.lastSeen || dataUser.lastSeen < cutoff) {
 inactive.push(jid);
 }
 }

 const totalMember = participants.length;
 const totalSider = inactive.length;

 let textRes = `📊 *Cek Sider Grup*\n\n📌 Periode: ${days} hari terakhir\n👥 Total Member: ${totalMember}\n😴 Sider: ${totalSider}\n\n`;

 if (inactive.length) {
 textRes += inactive.map(jid => `@${jid.split('@')[0]}`).join('\n');
 } else {
 textRes += '_Semua member aktif 👍_';
 }

 textRes += `\n\n⚠️ Jika dalam ${days} hari member tidak aktif, admin boleh ambil tindakan.`;

 await Kyle.sendMessage(m.chat, { text: textRes, mentions: inactive }, { quoted: m });

 } catch (e) {
 console.log(chalk.red('[ceksider] Error:'), e);
 balas('Terjadi kesalahan saat cek sider');
 }
}
break;



case 'rank': {
 try {
 const groupId = m.chat
 const userId = m.sender
 const pushName = m.pushName || userId.split("@")[0]

 const meta = await Kyle.groupMetadata(groupId).catch(() => null)
 if (!meta) return balas('⚠️ Gagal ambil metadata grup')
 const totalMember = meta.participants.length

 let userData, posisi, keaktifan

 if (global.ownerbut.includes(userId)) {
 userData = { messages: '∞', rank: 'Boundless 😈', name: 'Developer👑' }
 posisi = '∞'
 keaktifan = '∞'
 } else {
 userData = rankDB[groupId]?.[userId] || { messages: 0, rank: 'Warrior', name: pushName }
 const leaderboard = Object.entries(rankDB[groupId] || {})
 .sort((a, b) => b[1].messages - a[1].messages)
 posisi = leaderboard.findIndex(([jid]) => jid === userId) + 1 || 'N/A'

 const msg = userData.messages
 if (msg < 100) keaktifan = "Pasif"
 else if (msg < 500) keaktifan = "Cukup Aktif"
 else if (msg < 1000) keaktifan = "Aktif"
 else keaktifan = "Sangat Aktif"
 }

 const teks = `📊 𝗜𝗡𝗙𝗢 𝗥𝗔𝗡𝗞 𝗞𝗔𝗠𝗨
👤 Nama : *${userData.name}*
💬 Jumlah pesan : *${userData.messages}*
🔥 Keaktifan : *${keaktifan}*
📊 Rank : *${userData.rank}*
🌐 Leaderboard : #${posisi} dari *${totalMember}* member
`

 const msg = await generateWAMessageFromContent(
 m.chat,
 {
 viewOnceMessage: {
 message: {
 interactiveMessage: proto.Message.InteractiveMessage.create({
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: true,
 ...await prepareWAMessageMedia({ image: { url: ppUrl } }, { upload: Kyle.waUploadToServer })
 }),
 body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 name: 'quick_reply',
 buttonParamsJson: JSON.stringify({
 display_text: '🔎 MyInfo',
 id: '.myinfo'
 })
 }
 ]
 })
 })
 }
 }
 },
 { quoted: qCans }
 )

 await Kyle.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
 } catch (e) {
 console.log('[ ERROR RANK ]', e)
 balas('⚠️ Terjadi kesalahan saat ambil data rank')
 }
}
break;

case 'lb': {
  try {
    const groupId = m.chat;
    const meta = await Kyle.groupMetadata(groupId).catch(() => null);
    if (!meta) return balas('⚠️ Gagal ambil metadata grup');
    const totalMember = meta.participants.length;

    const groupRank = rankDB[groupId] || {};
    if (!Object.keys(groupRank).length) return balas('Belum ada data rank di grup ini.');

    // Urutkan berdasarkan messages terbanyak
    const leaderboard = Object.entries(groupRank)
      .sort((a, b) => b[1].messages - a[1].messages)
      .slice(0, 10); // 1-10

    let teks = `🏆 𝗟𝗘𝗔𝗗𝗘𝗥𝗕𝗢𝗔𝗥𝗗 𝗚𝗥𝗨𝗣 (1-10)\n\n`;
    
    leaderboard.forEach(([jid, data], index) => {
      teks += `#${index + 1} ${data.name} (${jid.split('@')[0]})\n`;
      teks += `💬 Pesan: ${data.messages} | Rank: ${data.rank}\n\n`;
    });

    const msg = await generateWAMessageFromContent(
      m.chat,
      {
        viewOnceMessage: {
          message: {
            interactiveMessage: proto.Message.InteractiveMessage.create({
              header: proto.Message.InteractiveMessage.Header.create({
                hasMediaAttachment: true,
                ...(await prepareWAMessageMedia(
                  { image: { url: ppUrl } },
                  { upload: Kyle.waUploadToServer }
                )),
              }),
              body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons: [
                  {
                    name: 'quick_reply',
                    buttonParamsJson: JSON.stringify({
                      display_text: 'CEK RANK',
                      id: '.rank'
                    })
                  }
                ]
              })
            })
          }
        }
      },
      { quoted: m }
    );

    await Kyle.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
  } catch (e) {
    console.log('[ ERROR LEADERBOARD ]', e);
    balas('⚠️ Terjadi kesalahan saat ambil leaderboard.');
  }
}
break;
case 'myinfo': {
 try {
 const linkTikTok = tiktokDB[m.sender];
 if (!linkTikTok) 
 return balas("⚠️ Kamu belum set link TikTok!\nGunakan: .daftar <linkProfilTikTok>");
 
 const match = linkTikTok.match(/tiktok\.com\/@([a-zA-Z0-9._]+)/);
 if (!match) 
 return balas("⚠️ Link TikTok tidak valid!");
 
 const username = match[1];

 // Panggil API Deline untuk info profil TikTok
 const res = await axios.get(`https://api.deline.my.id/stalker/ttstalk?username=${username}`);
 if (!res.data.status || !res.data.result) 
 return balas("⚠️ Gagal mengambil data profil TikTok.");

 const user = res.data.result.user;
 const stats = res.data.result.stats;
// Convert createTime ke tanggal readable
const createdAt = user.createTime 
  ? new Date(user.createTime * 1000).toLocaleDateString('id-ID', { 
     weekday:'long', year:'numeric', month:'long', day:'numeric' 
    }) 
  : '-';
 const caption = `
✨ 𝐓𝐢𝐤𝐓𝐨𝐤 𝐏𝐫𝐨𝐟𝐢𝐥𝐞 ✨
📛 Nickname: ${user.nickname || '-'}
📑 Username: @${user.uniqueId || username}
👥 Followers: ${stats.followerCount || 0}
👤 Following: ${stats.followingCount || 0}
❤️ Likes: ${stats.heartCount || 0}
📝 Bio: ${user.signature || '-'}
📅 Dibuat pada: ${createdAt}
`;

 const msg = await generateWAMessageFromContent(
 m.chat,
 {
 viewOnceMessage: {
 message: {
 messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
 footer: proto.Message.InteractiveMessage.Footer.create({ text: global.foot || '' }),
 header: proto.Message.InteractiveMessage.Header.create({
 ...(await prepareWAMessageMedia(
 { image: { url: user.avatarMedium || ppUrl } },
 { upload: Kyle.waUploadToServer }
 )),
 title: `✨ TikTok Profile`,
 subtitle: `@${user.uniqueId || username}`,
 hasMediaAttachment: true
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 name: 'cta_url',
 buttonParamsJson: JSON.stringify({
 display_text: 'Buka TikTok',
 url: `https://www.tiktok.com/@${user.uniqueId || username}`
 })
 }
 ]
 })
 })
 }
 }
 },
 { quoted: m }
 );

 await Kyle.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

 } catch (err) {
 console.error('ERR:', err);
 m.reply(`[ x ] Terjadi kesalahan sistem:\n${err.message}`);
 }
}
break;
case 'cn': {
 if (!text) return balas("⚠️ Masukkan nama dulu!\nContoh: .cn Kyle");

 const nama = text.trim();
 const font1 = generateFont(nama, 1);
 const font2 = generateFont(nama, 2);
const beng = `${font2} 𝖋𝖙 𝐂𝐒𝐊
—${font1} 𝑪𝑺𝑲࿐
𝙲𝚂𝙺 ${font2}`
 const hasil = `
${font2} 𝖋𝖙 𝐂𝐒𝐊
—${font1} 𝑪𝑺𝑲࿐
𝙲𝚂𝙺 ${font2}
cn for @${m.sender.split('@')[0]}\n

*JANGAN LUPA PAKAI HASTAG:*
#margacsk #creatorsukakurumi

`

 // Buat interactive message dengan tombol cta_copy
 const msg = await generateWAMessageFromContent(
 m.chat,
 {
 viewOnceMessage: {
 message: {
 messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({ text: hasil }),
 footer: proto.Message.InteractiveMessage.Footer.create({ text: global.foot || '' }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 name: 'cta_copy',
 buttonParamsJson: JSON.stringify({
 display_text: 'Salin CN',
 copy_code: beng
 })
 }
 ]
 })
 })
 }
 }
 },
 { quoted: m }
 );

 await Kyle.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break;

case 'hd2':{
 if (!quoted) return balas('⚠️ Reply atau kirim foto dulu!');
 const mime = (quoted.msg || quoted).mimetype || '';
 if (!/image/.test(mime)) return balas("⚠️ Mana fotonya?");
 
 await reactLoading(m);

 // Download media
 let media = await Kyle.downloadAndSaveMediaMessage(quoted);
 const fs = require('fs');
 const FormData = require('form-data');

 // Upload ke Catbox
 const tempPath = `./temp/${global.namabot}_${Date.now()}.jpg`;
 fs.writeFileSync(tempPath, media);
 const form = new FormData();
 form.append('reqtype', 'fileupload');
 form.append('fileToUpload', fs.createReadStream(tempPath));
 const catboxRes = await axios.post('https://catbox.moe/user/api.php', form, { headers: form.getHeaders() });
 fs.unlinkSync(tempPath);

 const fileUrl = catboxRes.data.trim();
 if (!fileUrl.includes('https://')) return balas("[ x ] Gagal upload ke Catbox!");

 // Proses HD/Remini via API Deline
 const apiUrl = `https://api.deline.my.id/tools/hd?url=${encodeURIComponent(fileUrl)}`;
 const { data } = await axios.get(apiUrl);
 if (!data?.result) return balas("⚠️ Gagal proses HD/Remini");

 // Ambil hasil image
 const imgBuffer = (await axios.get(data.result, { responseType: 'arraybuffer' })).data;

 // Kirim hasil ke chat
 await Kyle.sendMessage(m.chat, { image: Buffer.from(imgBuffer) }, { quoted: qCans });
}
break;



case 'groupmenu': {
 try {
 const caption = `
╭「 \`𝐌𝐄𝐍𝐔 𝐆𝐑𝐎𝐔𝐏\` 」────╮
│ *.ᴡᴇʟᴄᴏᴍᴇ [ ᴏɴ ᴏғғ 𝐬ᴇᴛ ]*
│ *.ɢᴏᴏᴅʙʏᴇ [ᴏɴ ᴏғғ 𝐬ᴇᴛ]*
│ *.ᴄᴇᴋ𝐬ɪᴅᴇʀ [ 𝐬ᴇᴛᴇʟᴀʜ ʙᴏᴛ ᴊᴏɪɴ 𝟕 ʜᴀʀɪ]*
│ *.ᴀɴᴛɪʟɪɴᴋᴀʟʟ [ ᴏɴ ᴏғғ ]*
│ *.ᴀɴᴛɪᴘʀᴏᴍᴏ𝐬ɪ [ ᴏɴ ᴏғғ ]*
│ *.ᴀɴᴛɪᴋᴀ𝐬ᴀʀ [ ᴏɴ ᴏғғ ]*
│ *.ᴀɴᴛɪᴛᴀɢ𝐬ᴡ [ ᴏɴ ᴏғғ ]*
│ *.ᴀɴᴛɪ𝐬ᴛɪᴄᴋᴇʀ [ ᴏɴ ᴏғғ ]*
│ *.ᴀɴᴛɪɪᴍɢ [ ᴏɴ ᴏғғ ]*
│ *.ᴀɴᴛɪᴠɪᴅᴇᴏ [ ᴏɴ ᴏғғ ]*
│ *.ʀᴀɴᴋ*
│ *.ᴍʏɪɴғᴏ*
│ *.ʜ / ʜɪᴅᴇᴛᴀɢ*
│ *.ᴋɪᴄᴋ*
│ *.ᴏᴘᴇɴᴛɪᴍᴇ*
│ *.ᴄʟᴏ𝐬ᴇᴛɪᴍᴇ*
│ *.ᴅᴇʟ*
│ *.ᴘʀᴏᴍᴏᴛᴇ*
│ *.ᴅᴇᴍᴏᴛᴇ*
│ *.ᴀʙsᴇɴ*
│ *.sᴀᴋɪᴛ*
│ *.ʀᴇᴋᴀᴘᴀʙsᴇɴ*
│ *.ᴄᴇᴋᴀʙsᴇɴ*
│ *.ᴄᴇᴋʜᴀsᴛᴀɢ*
│ *.sᴇᴛᴄɴ*
│ *.ᴅᴇʟsᴇᴛᴄɴ*
│ *.ᴄɴ*
│ *.ʟᴇᴀᴅᴇʀʙᴏᴀʀᴅ*
╰───────────────────╯
`;
const buttons = [

 {

 name: "cta_url",

 buttonParamsJson: JSON.stringify({

 display_text: "𝐊𝐎𝐍𝐓𝐀𝐊 𝐎𝐖𝐍𝐄𝐑",

 url: "https://wa.me/6283854859219?text=Kyle%20Mau%20beli%20Bot%20ini%20dong"

 })

 }

]
 const msg = await generateWAMessageFromContent(
 m.chat,
 {
 viewOnceMessage: {
 message: {
 messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
 footer: proto.Message.InteractiveMessage.Footer.create({ text: global.foot || '' }),
 header: proto.Message.InteractiveMessage.Header.create({
 ...(await prepareWAMessageMedia(
 { image: { url: ppUrl } },
 { upload: Kyle.waUploadToServer }
 )),
 title: `📌 MENU GROUP`,
 subtitle: `Fitur lengkap untuk manajemen group`,
 hasMediaAttachment: true
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons })
 })
 }
 }
 },
 { quoted: m }
 );

 await Kyle.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
 } catch (err) {
 console.error(err);
 balas("⚠️ Terjadi kesalahan saat menampilkan menu group.");
 }
}
break;

case 'menutools': {
 try {
 const caption = `
╭──「 \`𝐌𝐄𝐍𝐔 𝐓𝐎𝐎𝐋𝐒\`」───╮
│ *.ʜᴅ*
│ *.ᴛᴏғɪɢᴜʀᴇ*
│ *.ʀᴇᴍᴏᴠᴇʙɢ*
│ *.ʙʀᴀᴛ*
│ *.𝐬ᴛɪᴄᴋᴇʀ*
│ *.ʜɪᴛᴀᴍᴋᴀɴ*
│ *.𝐬ᴍᴇᴍᴇ*
│ *.ᴘɪɴᴛᴇʀᴇ𝐬ᴛ*
│ *.ɪǫᴄ*
│ *.ᴡʜᴀᴛᴀɴɪᴍᴇ*
│ *.ᴇᴍᴏᴊɪɢɪғ*
╰───────────────────╯
`;
const buttons = [

 {

 name: "cta_url",

 buttonParamsJson: JSON.stringify({

 display_text: "𝐊𝐎𝐍𝐓𝐀𝐊 𝐎𝐖𝐍𝐄𝐑",

 url: "https://wa.me/6283854859219?text=Kyle%20Mau%20beli%20Bot%20ini%20dong"

 })

 }

]
 const msg = await generateWAMessageFromContent(
 m.chat,
 {
 viewOnceMessage: {
 message: {
 messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
 interactiveMessage: proto.Message.InteractiveMessage.create({
 body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
 footer: proto.Message.InteractiveMessage.Footer.create({ text: global.foot || '' }),
 header: proto.Message.InteractiveMessage.Header.create({
 ...(await prepareWAMessageMedia(
 { image: { url: ppUrl } },
 { upload: Kyle.waUploadToServer }
 )),
 title: `📌 MENU TOOLS`,
 subtitle: `Fitur tools`,
 hasMediaAttachment: true
 }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons })
 })
 }
 }
 },
 { quoted: m }
 );

 await Kyle.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
 } catch (err) {
 console.error(err);
 balas("⚠️ Terjadi kesalahan saat menampilkan menu tools.");
 }
}
break;
case 'menu': {
const teksinfobot = `
👋 Halo, user keren! Aku *${global.botname}*, si bot multitalenta yang siap bantu kamu.

💡 Fitur Bot:
- Group Management 🛡️
- Tools Maybe It Helps You🛠️

✨ Versi: 3.4
🛠️ Developer: KyleDev
📢 Note: Masih tahap pengembangan, jadi mohon maklum kalau ada error atau delay.

📌 Klik tombol di bawah untuk kontak developer atau akses menu interaktif.
`;

  const button = [
    {
      name: "single_select",
      buttonParamsJson: JSON.stringify({
        title: "Pilih Menu Bot",
        sections: [
          {
            title: "Daftar Menu",
            highlight_label: "New",
            rows: [
              { title: "Menu Group", description: "Menu untuk group", id: ".groupmenu" },
              { title: "Menu Tools", description: "Menu tools bot", id: ".menutools" }
            ]
          }
        ]
      })
    },
    {
      name: "cta_url",
      buttonParamsJson: JSON.stringify({
        display_text: "𝐂𝐎𝐍𝐓𝐀𝐂𝐓 𝐃𝐄𝐕",
        url: "https://wa.me/6283854859219"
      })
    }
  ];

  // Siapkan media thumbnail
  const thumb = await prepareWAMessageMedia(
    { image: { url: ppUrl }},
    { upload: Kyle.waUploadToServer }
  );

  const msg = generateWAMessageFromContent(
    m.chat,
    {
      viewOnceMessage: {
        message: {
          messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            body: proto.Message.InteractiveMessage.Body.create({ text: teksinfobot }),
            footer: proto.Message.InteractiveMessage.Footer.create({ text: global.foot || '' }),
            header: proto.Message.InteractiveMessage.Header.create({
              ...thumb,
              title: "📜 MENU BOT"
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons: button })
          })
        }
      }
    },
    { userJid: m.sender, quoted: m }
  );

  await Kyle.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
}
break;

case 'menuowner':{
balas(`*GAK ADA MENU OWNER, PRIVATE 🤪*`) 
}
break;        
case 'addcase': {
  if (!isCreator) return 
  if (!text.includes("case '")) return example('case nya');

  const fs = require('fs');
  const namaFile = 'Kyle.js';
  const caseBaru = `${text.trim()}`;

  try {
    const data = fs.readFileSync(namaFile, 'utf8');
    const posisiTarget = data.indexOf("case 'addcase':");

    if (posisiTarget !== -1) {
      const kodeBaruLengkap = data.slice(0, posisiTarget) + '\n' + caseBaru + '\n' + data.slice(posisiTarget);
      fs.writeFileSync(namaFile, kodeBaruLengkap, 'utf8');
      m.reply(`[ ✓ ] Berhasil menyisipkan case baru!\nSilakan restart bot agar case aktif.`);
    } else {
      m.reply('[ x ] Tidak ditemukan posisi target untuk menyisipkan case!');
    }
  } catch (err) {
    console.error(err);
    m.reply('[ x ] Terjadi error saat membaca/menulis file!');
  }
}
break;
case 'delcase': {
  if (!isCreator) return 
  if (!text) return example('nama case');

  const fs = require('fs');
  const namaFile = 'Kyle.js';
  const namaCase = text.trim();

  try {
    let isiFile = fs.readFileSync(namaFile, 'utf8');

    const regex = new RegExp(`case ['"]${namaCase}['"]:[\\s\\S]*?break;`, 'g');
    if (!regex.test(isiFile)) return m.reply(`[ x ] Case '${namaCase}' tidak ditemukan!`);

    const isiBaru = isiFile.replace(regex, '');
    fs.writeFileSync(namaFile, isiBaru, 'utf8');

    m.reply(`[ ✓ ] Case '${namaCase}' berhasil dihapus!\nSilakan restart bot.`);
  } catch (err) {
    console.error(err);
    m.reply('[ x ] Gagal menghapus case! Cek kembali struktur file.');
  }
}
break;
case 'getcase': {
  if (!isCreator) return 
  if (!text) return example('nama case');
  
  const namaFile = 'Kyle.js';
  const namaCase = text.trim();

  try {
    const isiFile = fs.readFileSync(namaFile, 'utf8');
    const regex = new RegExp(`(case ['"]${namaCase}['"]:[\\s\\S]*?break;)`, 'g');
    const cocok = isiFile.match(regex);

    if (!cocok) return m.reply(`[ x ] Case '${namaCase}' tidak ditemukan!`);

    const isiCase = cocok[0];

    const msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            body: proto.Message.InteractiveMessage.Body.create({
              text: isiCase
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {
                  name: 'cta_copy',
                  buttonParamsJson: JSON.stringify({
                    display_text: 'Salin Case',
                    copy_code: isiCase
                  })
                }
              ]
            })
          })
        }
      }
    }, { userJid: m.sender, quoted: m });

    await Kyle.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

  } catch (err) {
    console.error(err);
    m.reply('[ x ] Gagal membaca isi case!');
  }
}
break;

case "addowner": {
        if (!isCreator) return 
        if (!text) return example("Tag atau sebut nomor yang ingin dijadikan owner!");
        let user = m.mentionedJid[0] || text.replace(/\D/g, '') + "@s.whatsapp.net";
        if (ownerList.includes(user)) return balas(`Nomor ${user.split('@')[0]} sudah menjadi owner!`);
        ownerList.push(user);
        await saveOwnerList();
        balas(`Berhasil menambahkan ${user.split('@')[0]} sebagai owner bot.`);
    }
    break;

    case "delowner": {
        if (!isCreator) return 
        if (!text) return example("Tag atau sebut nomor owner yang ingin dihapus!");
        let user = m.mentionedJid[0] || text.replace(/\D/g, '') + "@s.whatsapp.net";
        if (!ownerList.includes(user)) return balas(`Nomor ${user.split('@')[0]} bukan owner!`);
        ownerList = ownerList.filter(o => o !== user);
        await saveOwnerList();
        balas(`Berhasil menghapus ${user.split('@')[0]} dari daftar owner bot.`);
    }
    break;
case 'ping':{
                const used = process.memoryUsage()
                const cpus = os.cpus().map(cpu => {
                    cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0)
                    return cpu
                })
                const cpu = cpus.reduce((last, cpu, _, {
                    length
                }) => {
                    last.total += cpu.total
                    last.speed += cpu.speed / length
                    last.times.user += cpu.times.user
                    last.times.nice += cpu.times.nice
                    last.times.sys += cpu.times.sys
                    last.times.idle += cpu.times.idle
                    last.times.irq += cpu.times.irq
                    return last
                }, {
                    speed: 0,
                    total: 0,
                    times: {
                        user: 0,
                        nice: 0,
                        sys: 0,
                        idle: 0,
                        irq: 0
                    }
                })
                let timestamp = speed()
                let latensi = speed() - timestamp
                neww = performance.now()
                oldd = performance.now()
                respon = `
Response Speed ${latensi.toFixed(4)} _Second_ \n ${oldd - neww} _miliseconds_\n\nRuntime : ${runtime(process.uptime())}

💻 Info Server
RAM: ${formatp(os.totalmem() - os.freemem())} / ${formatp(os.totalmem())}

_NodeJS Memory Usaage_
${Object.keys(used).map((key, _, arr) => `${key.padEnd(Math.max(...arr.map(v=>v.length)),' ')}: ${formatp(used[key])}`).join('\n')}

${cpus[0] ? `_Total CPU Usage_
${cpus[0].model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}
_CPU Core(s) Usage (${cpus.length} Core CPU)_
${cpus.map((cpu, i) => `${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times).map(type => `- *${(type + '*').padEnd(6)}: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}`).join('\n\n')}` : ''}
`
balas(respon);
}
break;
//——————————[ Menu Tools ]——————————//

case 'pinterest': case 'pin': {
    if (!text) return balas(`Format salah, contoh:\n${prefix + command} Kyle`);
await reactLoading(m);
    let parts = text.trim().split(' ');
    let possibleIndex = parseInt(parts[parts.length - 1]);
    let keyword = text;
    let index = 0;

    if (!isNaN(possibleIndex)) {
        index = possibleIndex - 1;
        parts.pop();
        keyword = parts.join(' ');
    }

    if (typeof pinterestSession !== 'object') pinterestSession = {};

    if (!pinterestSession[m.chat] || pinterestSession[m.chat].keyword !== keyword) {
        let anutrest = await pinterest(keyword);
        if (!anutrest || anutrest.length === 0) return reply("Gambar tidak ditemukan!");
        pinterestSession[m.chat] = {
            keyword,
            results: anutrest,
            currentIndex: 0
        };
    }

    let session = pinterestSession[m.chat];
    let results = session.results;

    if (index >= results.length || index < 0) index = 0;
    session.currentIndex = index;

    let imageData = results[index];
    let nextIndex = (index + 1) % results.length + 1;
    let teksnya =
        `*Diunggah oleh* : ${imageData.upload_by}\n` +
        `*Nama Lengkap* : ${imageData.fullname}\n` +
        `*Pengikut* : ${imageData.followers}\n` +
        `*Caption* : ${imageData.caption}\n` +
        `\nGambar ${index + 1} dari ${results.length}`;

    const messageContent = await prepareWAMessageMedia({ image: { url: imageData.image } }, { upload: Kyle.waUploadToServer });

    let msgii = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                    contextInfo: { mentionedJid: [m.sender] },
                    body: proto.Message.InteractiveMessage.Body.create({ text: teksnya }),
                    footer: proto.Message.InteractiveMessage.Footer.create({ text: foot }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        ...messageContent,
                        title: `\`⟪ ${global.botname} - ${versi} ⟫\``,
                        subtitle: botname,
                        hasMediaAttachment: true
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                        buttons: [
                            {
                                name: "quick_reply",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "Next",
                                    id: `${prefix}pin ${keyword} ${nextIndex}`
                                })
                            }
                        ]
                    })
                })
            }
        }
    }, { userJid: m.sender, quoted: qwa });

    await Kyle.relayMessage(msgii.key.remoteJid, msgii.message, { messageId: msgii.key.id });
}
break;
case "superhd":
case "hd":
case "remini": {
  if (!quoted) return example('Reply/send image');
  if (!/image/.test(mime)) return balas("Mana fotonya");
  await reactLoading(m);
  let foto = await Kyle.downloadAndSaveMediaMessage(quoted);
  let buffer = fs.readFileSync(foto);
  const uploadCatbox = async (buf) => {
    const FormData = require("form-data");
    const form = new FormData();
    form.append("reqtype", "fileupload");
    form.append("fileToUpload", buf, "image.jpg");
    const res = await axios.post("https://catbox.moe/user/api.php", form, {
      headers: form.getHeaders(),
    });
    return res.data;
  };
  const reminiRyuu = async (buf) => {
    const url = await uploadCatbox(buf);
    const apiUrl = `https://api.ryuu-dev.offc.my.id/imagecreator/remini?apikey=RyuuGanteng&url=${encodeURIComponent(url)}`;
    const { data } = await axios.get(apiUrl);
    if (data?.status && data?.result) {
      const imgBuffer = (await axios.get(data.result, { responseType: "arraybuffer" })).data;
      return Buffer.from(imgBuffer);
    } else {
      throw new Error("Gagal proses remini API");
    }
  };
  if (command === "superhd") {
    let angka = parseInt(args[0]) || 5;
    if (angka > 10) angka = 10;

    for (let i = 0; i < angka; i++) {
      buffer = await reminiRyuu(buffer);
    }
    await Kyle.sendMessage(m.chat, { image: buffer }, { quoted: qCans });
  } else {
    let result = await reminiRyuu(buffer);
    await Kyle.sendMessage(m.chat, { image: result }, { quoted: qCans });
  }

  await fs.unlinkSync(foto);
}
break;
case 'tourl': {
  const qmsg = m.quoted || m;
  const mime = (qmsg.msg || qmsg).mimetype || '';
  const allowed = /image|video|audio|application|sticker/;

  if (!allowed.test(mime)) {
    return balas(`[ ! ] Kirim atau balas media (foto, video, dokumen, audio, stiker, dll) dengan perintah *${prefix + command}*`);
  }

  let media = await qmsg.download();
  if (!media) return balas("[ x ] Gagal mengunduh media!");

  try {
    await reactLoading(m);

    if (!fs.existsSync('./temp')) fs.mkdirSync('./temp');

    const extension = mime.split('/')[1] || 'bin';
    const fileName = `${global.namabot}_${Date.now()}.${extension}`;
    const filePath = `./temp/${fileName}`;
    fs.writeFileSync(filePath, media);

    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('fileToUpload', fs.createReadStream(filePath));

    const res = await axios.post('https://catbox.moe/user/api.php', form, {
      headers: form.getHeaders()
    });

    fs.unlinkSync(filePath);

    const url = res.data.trim();
    if (!url.includes('https://')) return balas("[ x ] Gagal upload ke Catbox!");

    const sizeKb = (media.length / 1024).toFixed(2);
    const caption = `*Upload Berhasil!*\n\n` +
      `*• Nama:* ${fileName}\n` +
      `*• Ukuran:* ${sizeKb} KB\n` +
      `*• Tipe:* ${mime}\n` +
      `*• Link:* ${url}`;

    const buttonMsg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2
          },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {
                  name: 'cta_copy',
                  buttonParamsJson: JSON.stringify({
                    display_text: 'Salin Link',
                    copy_code: url
                  })
                }
              ]
            })
          })
        }
      }
    }, { userJid: m.sender, quoted: m });

    await Kyle.relayMessage(m.chat, buttonMsg.message, { messageId: buttonMsg.key.id });

  } catch (err) {
    console.error(err);
    balas("[ x ] Terjadi kesalahan saat upload ke Catbox!");
  }
}
break;
case 'whatanime': {
    const qmsg = m.quoted || m;
    const mime = (qmsg.msg || qmsg).mimetype || '';
    if (!/image/.test(mime)) return balas(`[ ! ] Kirim atau balas gambar dengan perintah *${prefix + command}*`);

    try {
        await reactLoading(m);

        // Download media
        const media = await qmsg.download();
        if (!media) return balas("[ x ] Gagal mengunduh media!");

        if (!fs.existsSync('./temp')) fs.mkdirSync('./temp');
        const fileName = `whatanime_${Date.now()}.jpg`;
        const filePath = `./temp/${fileName}`;
        fs.writeFileSync(filePath, media);

        // Upload ke Catbox
        const form = new FormData();
        form.append('reqtype', 'fileupload');
        form.append('fileToUpload', fs.createReadStream(filePath));
        const resCatbox = await axios.post('https://catbox.moe/user/api.php', form, { headers: form.getHeaders() });
        fs.unlinkSync(filePath);

        const imageUrl = resCatbox.data.trim();
        if (!imageUrl.includes('https://')) return balas("[ x ] Gagal upload ke Catbox!");

        // Kirim ke API Deline WhatAnime
        const res = await axios.get(`https://api.deline.my.id/tools/whatanime?url=${encodeURIComponent(imageUrl)}`);
        if (!res.data.status) return balas('⚠️ Anime tidak ditemukan.');

        const data = res.data.result;
        const msgText = `🎬 *Hasil Pencarian WhatAnime*\n\n` +
                        `📌 *Judul:* ${data.title}\n` +
                        `👤 *Karakter:* ${data.character}\n` +
                        `🎭 *Genre:* ${data.genres.join(', ')}`;

        const buttons = [
            {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                    display_text: "🔗 MyAnimeList",
                    url: data.references.find(r => r.includes('myanimelist.net')) || data.source
                })
            }
        ];

        const msg = await generateWAMessageFromContent(
            m.chat,
            {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            body: proto.Message.InteractiveMessage.Body.create({ text: msgText }),
                            header: proto.Message.InteractiveMessage.Header.create({
                                hasMediaAttachment: true,
                                ...(await prepareWAMessageMedia({ image: { url: data.source } }, { upload: Kyle.waUploadToServer })),
                                title: `🎥 WhatAnime`
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons })
                        })
                    }
                }
            },
            { quoted: m }
        );

        await Kyle.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    } catch (err) {
        console.error(err);
        balas('[ x ] Terjadi kesalahan saat memproses gambar.');
    }
}
break;
//——————————[ Menu Sticker ]——————————//
case 'sticker':
case 'stiker':
case 's': {
  if (!quoted || (!/image/.test(mime) && !/video/.test(mime))) return example(`Kirim atau reply foto/video`);
await reactLoading(m);
  let media = await Kyle.downloadAndSaveMediaMessage(quoted);
  let stickerOptions = {
    packname: global.packname || 'KyleBotz',
    author: global.author || ' AI'
  };

  try {
    await Kyle.sendImageAsSticker(m.chat, media, m, stickerOptions);
  } catch {
    try {
      await Kyle.sendVideoAsSticker(m.chat, media, m, {
        ...stickerOptions,
        fps: 10,
        loop: 0
      });
    } catch (err) {
      console.error(err);
      balas('[ x ] Gagal membuat stiker.');
    }
  }

  fs.unlinkSync(media);
}
break;
//——————————[ Menu Group ]——————————//
case 'opentime': {
  if (!m.isGroup) return
  if (!isAdmins && !isCreator) return 
  if (!db.groups) db.groups = {};
  if (!db.groups[m.chat]) db.groups[m.chat] = { opentime: null, closetime: null };

  if (!text) return balas(`Gunakan:\n.opentime <durasi>\n\nContoh:\n.opentime 10s\n.opentime 5m\n.opentime 2h\n.opentime 1d`);

  let duration = parseDuration(text);
  if (!duration) return reply(`Format salah!\nGunakan s (detik), m (menit), h (jam), d (hari)`);

  let targetTime = Date.now() + duration;
  db.groups[m.chat].opentime = targetTime;
  fs.writeFileSync('./database/set.json', JSON.stringify(db, null, 2));

  balas(`⏰ Grup akan dibuka otomatis pada: *${formatTime(targetTime)}*`);

  setTimeout(async () => {
    try {
      await Kyle.groupSettingUpdate(m.chat, 'not_announcement');
      await Kyle.sendMessage(m.chat, {
        text: `[  ✓  ] Grup telah dibuka sesuai pengaturan admin.\nWaktu buka: *${formatTime(Date.now())}*`
      });
    } catch (e) {
      console.log("OpenTime error:", e.message);
    }
  }, duration);
}
break;

case 'closetime': {
  if (!m.isGroup) return 
  if (!isBotAdmins) return 
  if (!isAdmins && !isCreator) return 
  if (!db.groups) db.groups = {};
  if (!db.groups[m.chat]) db.groups[m.chat] = { opentime: null, closetime: null };

  if (!text) return reply(`Gunakan:\n.closetime <durasi>\n\nContoh:\n.closetime 10s\n.closetime 5m\n.closetime 2h\n.closetime 1d`);

  let duration = parseDuration(text);
  if (!duration) return reply(`Format salah!\nGunakan s (detik), m (menit), h (jam), d (hari)`);

  let targetTime = Date.now() + duration;
  db.groups[m.chat].closetime = targetTime;
  fs.writeFileSync('./database/set.json', JSON.stringify(db, null, 2));

  balas(`⏰ Grup akan ditutup otomatis pada: *${formatTime(targetTime)}*`);

  setTimeout(async () => {
    try {
      await Kyle.groupSettingUpdate(m.chat, 'announcement');
      await Kyle.sendMessage(m.chat, {
        text: `🚫 Grup telah ditutup sesuai pengaturan admin.\nWaktu tutup: *${formatTime(Date.now())}*`
      });
    } catch (e) {
      console.log("CloseTime error:", e.message);
    }
  }, duration);
}
break;

case 'antiimage': {
  if (!m.isGroup) return 
  if (!isBotAdmins) return 
  if (!isAdmins) return 
  if (!db.groups) db.groups = {};
  if (!db.groups[m.chat]) db.groups[m.chat] = { antiimage: false };

  if (!text) return balas(`Gunakan:\n.antiimage on\n.antiimage off`);
  const opt = text.toLowerCase();

  if (opt === 'on') {
    db.groups[m.chat].antiimage = true;
    m.reply(`[ ✓ ] AntiImage diaktifkan di grup ini.`);
  } else if (opt === 'off') {
    db.groups[m.chat].antiimage = false;
    m.reply(`[ x ] AntiImage dimatikan di grup ini.`);
  } else {
    m.reply(`Opsi tidak dikenal! Pilih: on / off`);
  }
  fs.writeFileSync('./database/set.json', JSON.stringify(db, null, 2));
}
break;

case 'antisticker': {
  if (!m.isGroup) return 
  if (!isBotAdmins) return 
  if (!isAdmins && !isCreator) return 
  if (!db.groups) db.groups = {};
  if (!db.groups[m.chat]) db.groups[m.chat] = { antisticker: false };

  if (!text) return balas(`Gunakan:\n.antisticker on\n.antisticker off`);
  const opt = text.toLowerCase();

  if (opt === 'on') {
    db.groups[m.chat].antisticker = true;
    m.reply(`[ ✓ ] AntiSticker diaktifkan di grup ini.`);
  } else if (opt === 'off') {
    db.groups[m.chat].antisticker = false;
    m.reply(`[ x ] AntiSticker dimatikan di grup ini.`);
  } else {
    m.reply(`Opsi tidak dikenal! Pilih: on / off`);
  }
  fs.writeFileSync('./database/set.json', JSON.stringify(db, null, 2));
}
break;

case 'antivid': {
 if (!m.isGroup) return
  if (!isAdmins && !isCreator) return 
 if (!db.groups) db.groups = {};
  if (!db.groups[m.chat]) db.groups[m.chat] = { antivideo: false };
  if (!text) return balas(`Gunakan:\n.antivideo on\n.antivideo off`);
  const opt = text.toLowerCase();
  if (opt === 'on') {
    db.groups[m.chat].antivideo = true;
    m.reply(`[ ✓ ] AntiVideo diaktifkan di grup ini.`);
  } else if (opt === 'off') {
   db.groups[m.chat].antivideo = false;
    m.reply(`[ x ] AntiVideo  dimatikan di grup ini.`);
  } else {
    m.reply(`Opsi tidak dikenal! Pilih: on / off`);
  }
  fs.writeFileSync('./database/set.json', JSON.stringify(db, null, 2));
}
break;
case 'modegroup': {
  try {
    if (!m.isGroup) return balas('❗Perintah ini hanya untuk grup.');
    if (!isAdmins && !isCreator) return balas('⚠️ Hanya admin/creator yang bisa mengatur mode grup.');

    // ensure db.groups exist
    if (!db.groups) db.groups = {};
    if (!db.groups[m.chat]) db.groups[m.chat] = {
      antitagsw: false,
      antilinkall: false,
      antibadword: false,
      welcome: false,
      welcomeText: null,
      goodbye: false,
      goodbyeText: null,
      antiimage: false,
      antisticker: false,
      antivideo: false
    };

    const group = db.groups[m.chat];

    // parse possible args: ".modegroup welcome on" OR from single_select id ".modegroup welcome on"
    const argsAll = text ? text.trim().split(/\s+/) : [];
    const argMode = argsAll[0] ? argsAll[0].toLowerCase() : null;
    const argOpt = argsAll[1] ? argsAll[1].toLowerCase() : null;

    // if has mode + opt => set directly
    if (argMode && argOpt) {
      // allowed keys mapping (prevent arbitrary property set)
      const allowed = ['antitagsw','antilinkall','antibadword','welcome','goodbye','antiimage','antisticker','antivideo'];
      if (!allowed.includes(argMode)) return balas('⚠️ Mode tidak dikenal.');
      if (argMode === 'welcome' || argMode === 'goodbye') {
        // welcome/goodbye only accept on/off here; use ".modegroup welcome set <text>" to set text
        if (argOpt === 'on') {
          group[argMode] = true;
          saveAndReply(`[ ✓ ] ${argMode} diaktifkan di grup ini.`);
        } else if (argOpt === 'off') {
          group[argMode] = false;
          saveAndReply(`[ x ] ${argMode} dimatikan di grup ini.`);
        } else {
          return balas('⚠️ Gunakan: .modegroup welcome on|off  atau .modegroup welcome set <teks>');
        }
      } else {
        // normal toggles
        group[argMode] = argOpt === 'on';
        saveAndReply(group[argMode] ? `[ ✓ ] ${argMode} diaktifkan di grup ini.` : `[ x ] ${argMode} dimatikan di grup ini.`);
      }
      fs.writeFileSync('./database/set.json', JSON.stringify(db, null, 2));
      break;
    }

    // handle "set" for welcome/goodbye text: .modegroup welcome set teks...
    if (argMode && argsAll[1] && argsAll[1].toLowerCase() === 'set') {
      const teks = argsAll.slice(2).join(' ').trim();
      if (!teks) return balas('⚠️ Masukkan teks untuk diset.\nContoh: .modegroup welcome set Selamat datang @user di @group');
      if (argMode !== 'welcome' && argMode !== 'goodbye') return balas('⚠️ Hanya welcome/goodbye yang bisa diset teksnya.');
      group[`${argMode}Text`] = teks;
      fs.writeFileSync('./database/set.json', JSON.stringify(db, null, 2));
      return balas(`[ ✓ ] Pesan ${argMode} berhasil diatur:\n${teks}`);
    }

    // no args => tampilkan menu single_select
    const statusList = [
      `AntiTagSW : ${group.antitagsw ? 'AKTIF ✅' : 'NONAKTIF ❌'}`,
      `AntiLinkAll : ${group.antilinkall ? 'AKTIF ✅' : 'NONAKTIF ❌'}`,
      `AntiKasar : ${group.antibadword ? 'AKTIF ✅' : 'NONAKTIF ❌'}`,
      `AntiImage : ${group.antiimage ? 'AKTIF ✅' : 'NONAKTIF ❌'}`,
      `AntiSticker : ${group.antisticker ? 'AKTIF ✅' : 'NONAKTIF ❌'}`,
      `AntiVideo : ${group.antivideo ? 'AKTIF ✅' : 'NONAKTIF ❌'}`,
      `Welcome : ${group.welcome ? 'AKTIF ✅' : 'NONAKTIF ❌'}`,
      `Goodbye : ${group.goodbye ? 'AKTIF ✅' : 'NONAKTIF ❌'}`
    ].join('\n');

    const caption = `⚙️ *Mode Group Saat Ini:*\n\n${statusList}\n\nPilih item di bawah untuk mengubah statusnya. Untuk mengatur teks welcome/goodbye pilih item lalu gunakan "set".`;

    // build options for single_select
    const optionsRows = [
      { title: 'AntiTagSW', description: group.antitagsw ? 'Matikan' : 'Aktifkan', id: '.modegroup antitagsw ' + (group.antitagsw ? 'off' : 'on') },
      { title: 'AntiLinkAll', description: group.antilinkall ? 'Matikan' : 'Aktifkan', id: '.modegroup antilinkall ' + (group.antilinkall ? 'off' : 'on') },
      { title: 'AntiKasar', description: group.antibadword ? 'Matikan' : 'Aktifkan', id: '.modegroup antibadword ' + (group.antibadword ? 'off' : 'on') },
      { title: 'AntiImage', description: group.antiimage ? 'Matikan' : 'Aktifkan', id: '.modegroup antiimage ' + (group.antiimage ? 'off' : 'on') },
      { title: 'AntiSticker', description: group.antisticker ? 'Matikan' : 'Aktifkan', id: '.modegroup antisticker ' + (group.antisticker ? 'off' : 'on') },
      { title: 'AntiVideo', description: group.antivideo ? 'Matikan' : 'Aktifkan', id: '.modegroup antivideo ' + (group.antivideo ? 'off' : 'on') },
      { title: 'Welcome', description: group.welcome ? 'Matikan / Set Teks' : 'Aktifkan / Set Teks', id: '.modegroup welcome ' + (group.welcome ? 'off' : 'on') },
      { title: 'Goodbye', description: group.goodbye ? 'Matikan / Set Teks' : 'Aktifkan / Set Teks', id: '.modegroup goodbye ' + (group.goodbye ? 'off' : 'on') }
    ];

    // create single_select interactive message
    const msg = await generateWAMessageFromContent(
      m.chat,
      {
        viewOnceMessage: {
          message: {
            messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
            interactiveMessage: proto.Message.InteractiveMessage.create({
              body: proto.Message.InteractiveMessage.Body.create({ text: caption }),
              footer: proto.Message.InteractiveMessage.Footer.create({ text: '© ModeGroup' }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons: [
                  {
                    name: 'single_select',
                    buttonParamsJson: JSON.stringify({
                      title: 'Pilih Mode',
                      sections: [
                        {
                          title: 'Pengaturan Mode',
                          rows: optionsRows.map(r => ({ title: r.title, description: r.description, id: r.id }))
                        }
                      ]
                    })
                  }
                ]
              })
            })
          }
        }
      },
      { quoted: qCans }
    );

    await Kyle.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

    // helper save + feedback
    function saveAndReply(textReply) {
      fs.writeFileSync('./database/set.json', JSON.stringify(db, null, 2));
      balas(textReply);
    }

  } catch (err) {
    console.error('MODEGROUP ERROR:', err);
    balas('Terjadi kesalahan saat mengakses mode group.');
  }
}
break;

case 'buka':
case 'tutup': {
  if (!m.isGroup) return 
  if (!isAdmins && isCreator) return 

  const isClose = command.toLowerCase() === 'tutup';
  const actionText = isClose ? 'menutup' : 'membuka';
  const doneText = isClose ? '[ x ] Grup telah ditutup hanya untuk admin.' : '[ ✓ ] Grup telah dibuka untuk semua member!';

  await Kyle.groupSettingUpdate(m.chat, isClose ? 'announcement' : 'not_announcement')
    .then(() => balas(`🔧 *Berhasil ${actionText} grup.*\n\n${doneText}`))
    .catch((err) => {
      console.error(err);
      m.reply('⚠️ Gagal mengubah pengaturan grup. Pastikan bot adalah admin!');
    });
}
break;
case 'kick': {
  if (!m.isGroup) return 
  if (!isAdmins && !isCreator) return

  let targets = [];

  if (m.quoted) targets.push(m.quoted.sender);
  if (m.mentionedJid.length) targets.push(...m.mentionedJid);
  if (targets.length === 0) return balas('❗ *Tag atau reply ke member yang ingin dikeluarkan!*');

  targets = [...new Set(targets)];

  for (let user of targets) {
    if (user === m.sender) continue; // Jangan kick yang ngeksekusi
    if (user === Kyle.user.jid) continue; // Jangan kick bot
    if (typeof global.owner === 'object' && global.owner.map ? global.owner.map(v => v + "@s.whatsapp.net").includes(user) : global.owner + "@s.whatsapp.net" === user) {
      m.reply(`⚠️ Tidak bisa mengeluarkan owner: @${user.split("@")[0]}`, { mentions: [user] });
      continue;
    }

    await Kyle.groupParticipantsUpdate(m.chat, [user], 'remove')
      .then(() => balas(`[ ✓ ] Berhasil mengeluarkan: @${user.split("@")[0]}`, { mentions: [user] }))
      .catch((err) => {
        console.error(err);
        balas(`[ x ] Gagal mengeluarkan: @${user.split("@")[0]}`, { mentions: [user] });
      });
  }
}
break;
case 'promote':
case 'demote': {
  if (!m.isGroup) return
  if (!isAdmins) return 

  const isPromote = command === 'promote';
  let target;

  if (m.quoted) {
    target = m.quoted.sender;
  } else if (m.mentionedJid?.length) {

    target = m.mentionedJid[0];
  } else {
    return reply(`🔖 *Tag atau reply member yang ingin di-${isPromote ? 'jadikan' : 'cabut'} admin.*`);
  }

  try {
    await Kyle.groupParticipantsUpdate(m.chat, [target], isPromote ? 'promote' : 'demote');
    balas(`[ ✓ ] *Berhasil ${isPromote ? 'menjadikan' : 'mencabut'} admin!*`);
  } catch (e) {
    console.error(e);
    balas(mesg.err);
  }
}
break;
case 'setcn': {
  if (!m.isGroup) return balas('❗Perintah ini hanya untuk grup.');
  if (!isAdmins && !isOwner) return balas('⚠️ Hanya admin yang bisa mengatur CN grup ini.');
  if (!text) return balas('📘 Format:\n.setcn ZC |nama| ft NCA');

  const groupId = m.chat;
  if (!cnData[groupId]) cnData[groupId] = [];

  if (cnData[groupId].length >= 3)
    return balas('🚫 Grup ini sudah memiliki 3 CN template.\nGunakan *.delsetcn* untuk menghapus salah satu.');

  cnData[groupId].push(text);
  saveCN();

  balas(`✅ CN baru ditambahkan ke grup ini!\nTotal CN sekarang: ${cnData[groupId].length}/3`);
}
break;

case 'delsetcn': {
  if (!m.isGroup) return balas('❗Perintah ini hanya untuk grup.');
  if (!isAdmins && !isOwner) return balas('⚠️ Hanya admin yang bisa menghapus CN.');

  const groupId = m.chat;
  if (!cnData[groupId] || cnData[groupId].length === 0)
    return balas('📭 Tidak ada CN yang tersimpan untuk grup ini.');

  let list = cnData[groupId].map((cn, i) => `${i + 1}. ${cn}`).join('\n');
  if (!text) return balas(`🗑️ CN Grup Ini:\n${list}\n\nKetik *.delsetcn 1* untuk hapus CN ke-1.`);

  const index = parseInt(text.trim()) - 1;
  if (isNaN(index) || index < 0 || index >= cnData[groupId].length)
    return balas('⚠️ Nomor CN tidak valid.');

  cnData[groupId].splice(index, 1);
  saveCN();

  balas('✅ CN berhasil dihapus.');
}
break;

case 'cn': {
  if (!text) return balas('⚠️ Masukkan nama!\nContoh: .cn Kyle');
  const groupId = m.chat;
  if (!cnData[groupId] || cnData[groupId].length === 0)
    return balas('📭 Grup ini belum memiliki CN template.\nGunakan *.setcn* untuk menambahkan.');

  const nama = text.trim();
  const hasilArray = cnData[groupId].map(t => renderCN(t, nama));
  const hasilTeks = hasilArray.map((x, i) => `${i + 1}. ${x}`).join('\n\n');

  const ctaCopy = hasilArray.join('\n\n');

  const msg = await generateWAMessageFromContent(
    m.chat,
    {
      viewOnceMessage: {
        message: {
          messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            body: proto.Message.InteractiveMessage.Body.create({
              text: `✨ *Generated CN untuk ${nama}:*\n\n${hasilTeks}`
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              text: '© CN Generator v3.5'
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {
                  name: 'cta_copy',
                  buttonParamsJson: JSON.stringify({
                    display_text: '📋 Salin Semua CN',
                    copy_code: ctaCopy
                  })
                }
              ]
            })
          })
        }
      }
    },
    { quoted: m }
  );

  await Kyle.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
break;
case 'delete': case 'del': case 'piw': {
  if (!m.isGroup) return 
  if (!isAdmins && m.key.participant !== m.sender) return 
  if (!m.quoted) return balas('🗑️ *Balas pesan yang ingin dihapus dengan perintah ini!*');

  try {
    await Kyle.sendMessage(m.chat, {
      delete: {
        remoteJid: m.chat,
        fromMe: false,
        id: m.quoted.id,
        participant: m.quoted.sender
      }
    });
  } catch (err) {
    console.error(err);
    reply(mesg.botadm);
  }
}
break;
case 'hidetag': case 'h': {
  if (!m.isGroup) return 
  if (!isAdmins && !isCreator) return 

  if (!text) return balas(`📢 *Contoh penggunaan:* ${prefix}${command} Pesan rahasia untuk semua`);

  const groupMetadata = await Kyle.groupMetadata(m.chat);
  const members = groupMetadata.participants.map(p => p.id);

  await Kyle.sendMessage(m.chat, {
    text: text,
    mentions: members
  }, { quoted: qCans });
}
break;
default:
if (m.text?.toLowerCase().includes("bot")) {
    const responses = [
        "Halo, aku di sini tau!",
        "Apa nih manggil bot? Butuh bantuan?",
        "Bot bot bot, aku punya nama tau, nama ku " + global.botname,
        "Iya sayang, aku di sini kok"
    ];
    const replyText = responses[Math.floor(Math.random() * responses.length)];
    await Kyle.sendMessage(m.chat, { text: replyText }, { quoted: qCans });
}
if (m.text?.toLowerCase().includes("kyle")) {
  const message = "Itu nama owner ku, mau beli SC kah? Nomor di bawah:";
  const buttons = [
    {
      name: "cta_url",
      buttonParamsJson: JSON.stringify({
        display_text: "📞 Hubungi Owner",
        url: "https://wa.me/6283854859219" // ganti dengan nomor owner
      })
    }
  ];

  const msg = await generateWAMessageFromContent(
    m.chat,
    {
      viewOnceMessage: {
        message: {
          messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            body: proto.Message.InteractiveMessage.Body.create({ text: message }),
            footer: proto.Message.InteractiveMessage.Footer.create({ text: global.foot || "" }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons })
          })
        }
      }
    },
    { quoted: qCans }
  );

  await Kyle.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}
                if (budy.startsWith('=>')) {
                    if (!isCreator) return

                    function Return(sul) {
                        sat = JSON.stringify(sul, null, 2)
                        bang = util.format(sat)
                        if (sat == undefined) {
                            bang = util.format(sul)
                        }
                        return balas(bang)
                    }
                    try {
                        balas(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
                    } catch (e) {
                        balas(String(e))
                    }
                }

                if (budy.startsWith('>')) {
                    if (!isCreator) return balas(mess.owner)
                    try {
                        let evaled = await eval(budy.slice(2))
                        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
                        await balas(evaled)
                    } catch (err) {
                        await balas(String(err))
                    }
                }
                if (budy.startsWith('$')) {
                    if (!isCreator) return balas(mess.owner)
                    exec(budy.slice(2), (err, stdout) => {
                        if (err) return balas(err)
                        if (stdout) return balas(stdout)
                    })
                }
        }
    } catch (err) {
        console.log(util.format(err))
    }
}
let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update ${__filename}`))
    delete require.cache[file]
    require(file)
})

process.on('uncaughtException', function (err) {
let e = String(err)
/*if (e.includes("conflict")) return
if (e.includes("Socket connection timeout")) return
if (e.includes("not-authorized")) return
if (e.includes("already-exists")) return
if (e.includes("rate-overlimit")) return
if (e.includes("Connection Closed")) return
if (e.includes("Timed Out")) return
if (e.includes("Value not found")) return*/
console.log('Caught exception: ', err)
})