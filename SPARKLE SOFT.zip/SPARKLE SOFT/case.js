require('./settings')
const {
  generateWAMessageFromContent,
  WAMessageStubType,
  generateWAMessageContent,
  generateWAMessage,
  prepareWAMessageMedia,
  downloadContentFromMessage,
  areJidsSameUser,
  InteractiveMessage,
  proto,
  delay
} = require('baileys')
const axios = require('axios')
const fs = require('fs')
const fetch = require('node-fetch')
const FormData = require('form-data')
const moment = require('moment-timezone')
const path = require('path')
const util = require('util')

const {
  fromBuffer
} = require('file-type')

const {
  exec,
  execSync
} = require('child_process')
const own = JSON.parse(fs.readFileSync('./database/owner.json').toString())
let setting = JSON.parse(fs.readFileSync('./lib/settings.json'))

const { rankDB, saveRank, updateRank } = require('./lib/rank')
module.exports = sock = async (sock, m, chatUpdate, mek, store) => {
  try {

    const chalk = require('chalk')
    const sourceFiles = [
      fs.readFileSync('./case.js', 'utf8')
    ]
    const regex = /case\s+'([^']+)':/g
    const matches = []
    for (const source of sourceFiles) {
      let match
      while ((match = regex.exec(source)) !== null) {
        matches.push(match[1])
      }
    }
    global.help = Object.values(matches)
      .flatMap(v => v ?? [])
      .map(entry => entry.trim().split(' ')[0].toLowerCase())
      .filter(Boolean)
    global.handlers = []

    const {
      type
    } = m
    const {
      parseMention,
      formatDuration,
      getRandom,
      getBuffer,
      fetchJson,
      runtime,
      sleep,
      isUrl,
      clockString,
      getTime,
      formatp,
      getGroupAdmins,
      pickRandom,
      monospace,
      randomKarakter,
      randomNomor,
      toRupiah,
      toDolar,
      FileSize,
      resize,
      nebal,
      totalFitur,
      smsg
    } = require('./lib/myfunc')

    const {
      CatBox,
      pinterest,
      yt_search,
      tiktokSearchVideo
    } = require('./lib/scrape')

    var body = m.body
    var budy = m.text
    var prefix
    if (setting.multiprefix) {
      prefix = body.match(/^[°zZ#@+,.?=''():√%!¢£¥€π¤ΠΦ&™©®Δ^βα¦|/\\©^]/)?.[0] || '.'
    } else {
      prefix = body.match(/^[#.?!]/)?.[0] || ''
    }
    const isCmd = body.startsWith(prefix)
    const command = isCmd ? body.slice(prefix.length).trim().split(' ')[0].toLowerCase() : ''
    const pushname = m.pushName || "No Name"
    const botNumber = await sock.decodeJid(sock.user.id)
    const bulan = moment.tz('Asia/Jakarta').format('DD/MMMM')
    const tahun = moment.tz('Asia/Jakarta').format('YYYY')
    const tanggal = moment().tz("Asia/Jakarta").format("dddd, d")
    const jam = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss')
    const wibTime = moment().tz('Asia/Jakarta').format('HH:mm:ss')
    const penghitung = moment().tz("Asia/Jakarta").format("dddd, D MMMM - YYYY")
    const args = body.trim().split(/ +/).slice(1)
    const full_args = body.replace(command, '').slice(1).trim()
    const text = q = args.join(" ")
    const quoted = m.quoted ? m.quoted : m
    const from = m.key.remoteJid
    const mime = (quoted.msg || quoted).mimetype || ''
    const isMedia = /image|video|sticker|audio/.test(mime)
    const isMediaa = /image|video/.test(mime)
    const isPc = from.endsWith('@s.whatsapp.net')
    const isGc = from.endsWith('@g.us')
    const more = String.fromCharCode(8206)
    const readmore = more.repeat(4001)
    const qmsg = (quoted.msg || quoted)
    const sender = m.key.fromMe ? (sock.user.id.split(':')[0] + '@s.whatsapp.net' || sock.user.id) : (m.key.participant || m.key.remoteJid)
    const groupMetadata = m.isGroup ? await sock.groupMetadata(m.chat) : ''
    const participants = m.isGroup ? await groupMetadata.participants : ''
    const groupAdmins = m.isGroup ? await participants.filter((v) => v.admin !== null).map((i) => i.id) : [] || []
    const groupOwner = m.isGroup ? groupMetadata?.owner : false
    const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false
    const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false
    const groupMembers = m.isGroup ? groupMetadata.participants : ''
    const froms = m.quoted ? m.quoted.sender : text ? (text.replace(/[^0-9]/g, '') ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false) : false
    const tag = `${m.sender.split('@')[0]}`
    const tagg = `${m.sender.split('@')[0]}` + '@s.whatsapp.net'
    const isImage = (type == 'imageMessage')
    const isVideo = (type == 'videoMessage')
    const isAudio = (type == 'audioMessage')
    const isSticker = (type == 'stickerMessage')
    const isOwner = [owner, ...own]
      .filter(v => typeof v === 'string' && v.trim() !== '')
      .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
      .includes(m.sender)
    const isReseller = [owner, ...own, ...res]
      .filter(v => typeof v === 'string' && v.trim() !== '')
      .map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
      .includes(m.sender)

    if (!setting.public) {
      if (!isOwner && !m.key.fromMe) return
    }
    const contacts = JSON.parse(fs.readFileSync('./database/contacts.json'))
    const isContacts = contacts.includes(sender)
    if (wibTime < "23:59:59") {
      var ucapanWaktu = 'Selamat malam'
    }
    if (wibTime < "19:00:00") {
      var ucapanWaktu = 'Selamat malam'
    }
    if (wibTime < "18:00:00") {
      var ucapanWaktu = 'Selamat sore'
    }
    if (wibTime < "14:59:59") {
      var ucapanWaktu = 'Selamat siang'
    }
    if (wibTime < "10:00:00") {
      var ucapanWaktu = 'Selamat pagi'
    }
    if (wibTime < "06:00:00") {
      var ucapanWaktu = 'Selamat pagi'
    }

    if (!setting.public) {
      if (!isOwner && !m.key.fromMe) return
    }

    const onlyAdmin = () => {
      m.reply('Fitur ini hanya dapat diakses oleh admin')
    }
    const onlyOwn = () => {
      m.reply('Fitur ini hanya dapat diakses oleh owner')
    }
    const onlyBotAdmin = () => {
      m.reply('Fitur ini hanya dapat diakses jika bot adalah admin')
    }
    const onlyGrup = () => {
      m.reply('Fitur ini hanya dapat diakses di group')
    }
    const onlyPrivat = () => {
      m.reply('Fitur ini hanya bisa di akses di private chat')
    }
    const onlyOr = () => {
      m.reply('Fitur ini hanya bisa diakses oleh reseller')
    }

    try {
      const currentTimee = Date.now()
      let isNumber = x => typeof x === 'number' && !isNaN(x)
      let user = global.db.data.users[m.sender]
      if (typeof user !== 'object') global.db.data.users[m.sender] = {}
      if (user) {
        if (!('daftar' in user)) user.daftar = false
        if (!('nama' in user)) user.nama = `${pushname}`
        if (!('banned' in user)) user.banned = false
      } else global.db.data.users[m.sender] = {
        daftar: false,
        nama: `${pushname}`,
        banned: false
      }
      let chats = global.db.data.chats[m.chat]
      if (typeof chats !== 'object') global.db.data.chats[m.chat] = {}
      if (chats) {
        if (!('antilink' in chats)) chats.antilink = false
        if (!('antilinkgc' in chats)) chats.antilinkgc = false
        if (!('welcome' in chats)) chats.welcome = false
        if (!('goodbye' in chats)) chats.goodbye = false
        if (!('warn' in chats)) chats.warn = {}
      } else global.db.data.chats[m.chat] = {
        antilink: false,
        antilinkgc: false,
        welcome: false,
        goodbye: false,
        warn: {}
      }

      fs.writeFileSync('./database/database.json', JSON.stringify(global.db, null, 2))
    } catch (err) {
      console.log(err)
    }

    const _p = prefix
    const n_cmd = command
    const p_c = prefix + command
    const reply = (teks) => {
      return sock.sendMessage(m.chat, {
        text: teks,
        mentions: sock.ments(teks)
      }, {
        quoted: m
      })
    }
const qKyle = {key: { participant: "0@s.whatsapp.net", remoteJid: `status@broadcast` }, message: {contactMessage: {displayName: `${global.ownername}`, isBusinessVerified: true }}}
    const ftext = {
      key: {
        participant: '0@s.whatsapp.net',
        ...(m.chat ? {
          remoteJid: `status@broadcast`
        } : {})
      },
      message: {
        extendedTextMessage: {
          text: `${command} ${text}`,
          thumbnailUrl: thumb
        }
      }
    }
    let rn = ['recording']
    let jd = rn[Math.floor(Math.random() * rn.length)];
    if (m.message && global.help.includes(command)) {
      let time = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('HH:mm:ss z')
      sock.sendPresenceUpdate('available', m.chat)

      const getDtckMsg = `
${chalk.bold.magenta('📥 WHATSAPP MESSAGE')}

${chalk.cyan('⏰ Time     :')} ${chalk.yellow(time)}
${chalk.cyan('💬 Chat     :')} ${chalk.green(m.isGroup ? 'Group 👥' : 'Private 🔒')}
${chalk.cyan('🙋 Sender   :')} ${chalk.hex('#FFA500')(m.pushName || 'Unknown')}
${chalk.cyan('🧩 Command  :')} ${chalk.redBright(command)}
`

      console.log(getDtckMsg)
    }


    if (budy.startsWith('=> ')) {
      if (!m.fromMe && !isOwner) return

      function Return(sul) {
        sat = JSON.stringify(sul, null, 2)
        bang = util.format(sat)
        if (sat == undefined) {
          bang = util.format(sul)
        }
        return m.reply(bang)
      }
      try {
        m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
      } catch (e) {
        m.reply(util.format(e))
      }
    }

    if (budy.startsWith('> ')) {
      if (!m.fromMe && !isOwner) return
      try {
        let evaled = await eval(budy.slice(2))
        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
        await m.reply(evaled)
      } catch (err) {
        await m.reply(util.format(err))
      }
    }

    if (budy.startsWith('$ ')) {
      if (!m.fromMe && !isOwner) return
      exec(budy.slice(2), (err, stdout) => {
        if (err) return m.reply(`${err}`)
        if (stdout) return m.reply(stdout)
      })
    }

    if (db.data.chats[m.chat].warn && db.data.chats[m.chat].warn[m.sender]) {
      const warnings = db.data.chats[m.chat].warn[m.sender]

      if (warnings >= setting.warnCount) {
        if (!isBotAdmins || isAdmins || isOwner) return

        await sock.sendMessage(m.chat, {
          delete: {
            remoteJid: m.chat,
            fromMe: false,
            id: m.key.id,
            participant: m.sender
          }
        })
      }
    }

    if (db.data.chats[m.chat].antilink) {
      if (budy.match('chat.whatsapp|wa.me|whatsapp.com|t.me|http|www.')) {
        if (!(m.key.fromMe || isAdmins || isOwner || !isBotAdmins)) {
          await sock.sendMessage(m.chat, {
            delete: {
              remoteJid: m.chat,
              fromMe: false,
              id: m.key.id,
              participant: m.key.participant
            }
          })
          await sock.groupParticipantsUpdate(m.chat, [m.sender], 'delete')
        }
      }
    }

    if (db.data.chats[m.chat].antilinkgc) {
      if (budy.match('chat.whatsapp')) {
        if (!(m.key.fromMe || isAdmins || isOwner || !isBotAdmins)) {
          await sock.sendMessage(m.chat, {
            delete: {
              remoteJid: m.chat,
              fromMe: false,
              id: m.key.id,
              participant: m.key.participant
            }
          })
          await sock.groupParticipantsUpdate(m.chat, [m.sender], 'delete')
        }
      }
    }

    if (setting.autoread) {
      sock.readMessages([m.key])
    }

    if (global.help.includes(command) && setting.autotyping) {
      sock.sendPresenceUpdate('composing', from)
      setTimeout(() => {
        sock.sendPresenceUpdate('paused', from)
      }, 2000)
    }

    async function react() {
      sock.sendMessage(from, {
        react: {
          text: '⏱️',
          key: m.key
        }
      })
    }
    const ppUrl = await sock.profilePictureUrl(m.chat, 'image').catch(() => global.thumb);

const ppUsr = await sock.profilePictureUrl(m.sender, 'image').catch(() = > ppUrl);
const detekPath = './database/detek.json';
function loadDetek() {
    let detekData = {};
    try { detekData = JSON.parse(fs.readFileSync(detekPath, 'utf-8')); } catch {}
    return detekData;
}
// Fungsi save detek.json
function saveDetek(data) {
    fs.writeFileSync(detekPath, JSON.stringify(data, null, 2));
}
const targetLinks = ['vt.tiktok.com','vm.tiktok.com','www.tiktok.com'];
if (m.text && targetLinks.some(link => m.text.includes(link))) {
  (async () => {
    try {
      const url = m.text.match(/https?:\/\/[^\s]+/g)[0];

      // Ambil data TikTok via TikWM API
      let videoData, nickname = 'Tidak ada', username = 'Tidak ada', caption = '', hashtags = [];
      try {
        const resTikwm = await axios.get('https://www.tikwm.com/api/', {
          params: { url, count: 1, hd: 1 },
          headers: {
            'User-Agent': 'Mozilla/5.0'
          }
        });
        if (resTikwm.data?.data) {
          videoData = resTikwm.data.data;
          nickname = videoData.author?.nickname || 'Tidak ada';
          username = videoData.author?.unique_id || 'Tidak ada';
        }
      } catch {}

      // Ambil caption & hashtag via Siputzx API
      try {
        const resSip = await axios.get(`https://api.siputzx.my.id/api/d/tiktok/v2?url=${encodeURIComponent(url)}`);
        if (resSip.data.status && resSip.data.data?.metadata) {
          caption = resSip.data.data.metadata.description || '';
          hashtags = resSip.data.data.metadata.hashtags || [];
        }
      } catch {}

      if (!videoData && !caption) return sock.sendMessage(m.chat, { text: "❌ Gagal ambil data TikTok." });

      // Load CN & hashtag grup
      const detekData = loadDetek();
   // Ambil data grup
const groupSettings = detekData[m.chat] || { tiktokHashtags: [], cnFonts: [] };

// Cek hashtag
const foundHashtags = groupSettings.tiktokHashtags.filter(h => caption.includes(h));
const notFoundHashtags = groupSettings.tiktokHashtags.filter(h => !foundHashtags.includes(h));

// Cek CN (bisa banyak)
const foundCN = groupSettings.cnFonts.filter(cn => nickname.includes(cn));

const uploadDate = videoData?.create_time
? new Date(videoData.create_time * 1000).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', dateStyle: 'full', timeStyle: 'short' })
: 'Tidak diketahui';
      // Format message
      
// Format pesan
let message = `👤 Nickname: ${nickname}\n🔗 Username: @${username}\n🍂Caption: ${caption}\n📅 Diposting pada: ${uploadDate}\n\n`;

// Hashtag
foundHashtags.forEach(h => message += `#️⃣ ${h} ✅ Terdeteksi\n`);
notFoundHashtags.forEach(h => message += `#️⃣ ${h} ❌ Tidak terdeteksi\n`);

// CN
if (foundCN.length > 0) {
  message += `🆔 CN ✅ Terdeteksi\n`; // minimal 1 cocok → cukup dianggap terdeteksi
} else if (groupSettings.cnFonts.length > 0) {
  message += `🆔 CN ❌ Tidak terdeteksi\n`; // semua CN tidak cocok
}


      const buttons = [
        {
          name: "cta_url",
          buttonParamsJson: JSON.stringify({ display_text: " KUNJUNGI VT", url })
        }
      ];

      const msg = await generateWAMessageFromContent(
        m.chat,
        {
          viewOnceMessage: {
            message: {
              messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
              interactiveMessage: proto.Message.InteractiveMessage.create({
                body: proto.Message.InteractiveMessage.Body.create({ text: message }),
                footer: proto.Message.InteractiveMessage.Footer.create({ text: global.foot || '' }),
                header: proto.Message.InteractiveMessage.Header.create({
                  ...(await prepareWAMessageMedia({ image: { url: global.thumb } }, { upload: sock.waUploadToServer })),
                  title: ".      🎥 Deteksi TikTok",
                  subtitle: nickname,
                  hasMediaAttachment: true
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({ buttons })
              })
            }
          }
        },
        { quoted: qKyle }
      );

      await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    } catch (err) {
      console.error("Error auto TikTok:", err);
      await sock.sendMessage(m.chat, { text: "⚠️ Terjadi kesalahan saat deteksi TikTok." });
    }
  })();
}
    switch (command) {
    case 'rvo':
    case 'readvo':
    case 'readviewonce': {
      if (!m.quoted) return m.reply('Kutip pesan view-once!')
      let msg = m.quoted
      let type = msg.mtype
      if (!msg.viewOnce) return m.reply('Itu bukan pesan view-once!')

      let media = await downloadContentFromMessage(
        msg,
        type === 'imageMessage' ? 'image' :
        type === 'videoMessage' ? 'video' : 'audio'
      )

      let buffer = Buffer.from([])
      for await (const chunk of media) {
        buffer = Buffer.concat([buffer, chunk])
      }

      let sendOptions = {
        quoted: qKyle
      }
      if (/video/.test(type)) {
        return sock.sendMessage(m.chat, {
          video: buffer,
          caption: msg.caption || ''
        }, sendOptions)
      } else if (/image/.test(type)) {
        return sock.sendMessage(m.chat, {
          image: buffer,
          caption: msg.caption || ''
        }, sendOptions)
      } else if (/audio/.test(type)) {
        return sock.sendMessage(m.chat, {
          audio: buffer,
          mimetype: 'audio/mpeg',
          ptt: true
        }, sendOptions)
      }
    }
    break
case 'lb': {
  try {
    const groupId = m.chat;
    const meta = await sock.groupMetadata(groupId).catch(() => null);
    if (!meta) return balas('⚠️ Gagal ambil metadata grup');
    const totalMember = meta.participants.length;

    const groupRank = rankDB[groupId] || {};
    if (!Object.keys(groupRank).length) return balas('Belum ada data rank di grup ini.');

    // Urutkan berdasarkan messages terbanyak
    const leaderboard = Object.entries(groupRank)
      .sort((a, b) => b[1].messages - a[1].messages)
      .slice(0, 10); // 1-10

    let teks = `🏆 𝗟𝗘𝗔𝗗𝗘𝗥𝗕𝗢𝗔𝗥𝗗 𝗚𝗥𝗨𝗣 (1-10)\n\n`;
    
    leaderboard.forEach(([jid, data], index) => {
      teks += `#${index + 1} ${data.name} (${jid.split('@')[0]})\n`;
      teks += `💬 Pesan: ${data.messages} | Rank: ${data.rank}\n\n`;
    });

    const msg = await generateWAMessageFromContent(
      m.chat,
      {
        viewOnceMessage: {
          message: {
            interactiveMessage: proto.Message.InteractiveMessage.create({
              header: proto.Message.InteractiveMessage.Header.create({
                hasMediaAttachment: true,
                ...(await prepareWAMessageMedia(
                  { image: { url: ppUrl } },
                  { upload: sock.waUploadToServer }
                )),
              }),
              body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
              nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                buttons: [
                  {
                    name: 'quick_reply',
                    buttonParamsJson: JSON.stringify({
                      display_text: 'CEK RANK',
                      id: '.rank'
                    })
                  }
                ]
              })
            })
          }
        }
      },
      { quoted: qKyle }
    );

    await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
  } catch (e) {
    console.log('[ ERROR LEADERBOARD ]', e);
    balas('⚠️ Terjadi kesalahan saat ambil leaderboard.');
  }
}
break;
case 'rank': {
 try {
 const groupId = m.chat
 const userId = m.sender
 const pushName = m.pushName || userId.split("@")[0]

 const meta = await sock.groupMetadata(groupId).catch(() => null)
 if (!meta) return balas('⚠️ Gagal ambil metadata grup')
 const totalMember = meta.participants.length

 let userData, posisi, keaktifan

 if (global.ownerbut.includes(userId)) {
 userData = { messages: '∞', rank: 'Boundless 😈', name: 'Developer👑' }
 posisi = '∞'
 keaktifan = '∞'
 } else {
 userData = rankDB[groupId]?.[userId] || { messages: 0, rank: 'Warrior', name: pushName }
 const leaderboard = Object.entries(rankDB[groupId] || {})
 .sort((a, b) => b[1].messages - a[1].messages)
 posisi = leaderboard.findIndex(([jid]) => jid === userId) + 1 || 'N/A'

 const msg = userData.messages
 if (msg < 100) keaktifan = "Pasif"
 else if (msg < 500) keaktifan = "Cukup Aktif"
 else if (msg < 1000) keaktifan = "Aktif"
 else keaktifan = "Sangat Aktif"
 }

 const teks = `📊 𝗜𝗡𝗙𝗢 𝗥𝗔𝗡𝗞 𝗞𝗔𝗠𝗨
👤 Nama : *${userData.name}*
💬 Jumlah pesan : *${userData.messages}*
🔥 Keaktifan : *${keaktifan}*
📊 Rank : *${userData.rank}*
🌐 Leaderboard : #${posisi} dari *${totalMember}* member
`

 const msg = await generateWAMessageFromContent(
 m.chat,
 {
 viewOnceMessage: {
 message: {
 interactiveMessage: proto.Message.InteractiveMessage.create({
 header: proto.Message.InteractiveMessage.Header.create({
 hasMediaAttachment: true,
 ...await prepareWAMessageMedia({ image: { url: ppUsr } }, { upload: sock.waUploadToServer })
 }),
 body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
 nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
 buttons: [
 {
 name: 'quick_reply',
 buttonParamsJson: JSON.stringify({
 display_text: '🔎 MyInfo',
 id: '.myinfo'
 })
 }
 ]
 })
 })
 }
 }
 },
 { quoted: qKyle }
 )

 await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
 } catch (e) {
 console.log('[ ERROR RANK ]', e)
 balas('⚠️ Terjadi kesalahan saat ambil data rank')
 }
}
break;
case 'setwelcome': {
  if (!isAdmins && !isOwner) return m.reply('❌ Hanya admin atau owner yang bisa mengubah teks welcome.')

  if (!text) return m.reply(`⚙️ Contoh:\n.setwelcome Welcome @user ke grup @group!\n\nGunakan:\n@user → nama user\n@group → nama grup\n@desc → deskripsi grup`)

  try {
    let data = JSON.parse(fs.readFileSync('./database/welcome.json'))
    if (!data[m.chat]) data[m.chat] = {}
    data[m.chat].text_welcome = text
    fs.writeFileSync('./database/welcome.json', JSON.stringify(data, null, 2))
    m.reply('✅ Teks welcome berhasil diubah!\n\nSekarang pesan welcome akan seperti ini:\n\n' + text)
  } catch (err) {
    console.log(chalk.redBright('Error saat setwelcome:'), err)
    m.reply('❌ Terjadi kesalahan saat menyimpan teks welcome.')
  }
  }
  break


case 'setleft': {
  if (!isAdmins && !isOwner) return m.reply('❌ Hanya admin atau owner yang bisa mengubah teks goodbye.')

  if (!text) return m.reply(`⚙️ Contoh:\n.setleft Goodbye @user dari grup @group!\n\nGunakan:\n@user → nama user\n@group → nama grup\n@desc → deskripsi grup`)

  try {
    let data = JSON.parse(fs.readFileSync('./database/welcome.json'))
    if (!data[m.chat]) data[m.chat] = {}
    data[m.chat].text_left = text
    fs.writeFileSync('./database/welcome.json', JSON.stringify(data, null, 2))
    m.reply('✅ Teks goodbye berhasil diubah!\n\nSekarang pesan goodbye akan seperti ini:\n\n' + text)
  } catch (err) {
    console.log(chalk.redBright('Error saat setleft:'), err)
    m.reply('❌ Terjadi kesalahan saat menyimpan teks goodbye.')
  }
  }
  break

    case 's':
    case 'stiker':
    case 'setiker':
    case 'sticker': {
      if (!quoted) return m.reply(`Kirim/kutip gambar dengan caption ${p_c}`)
      react()

      if (quoted) {
        let msg = quoted
        let type = Object.keys(msg)[0]
        if (msg[type].viewOnce) {
          let media = await downloadContentFromMessage(msg[type], type == 'imageMessage' ? 'image' : 'video')
          let buffer = Buffer.from([])
          for await (const chunk of media) {
            buffer = Buffer.concat([buffer, chunk])
          }
          if (/video/.test(type)) {
            if ((quoted.msg || quoted).seconds > 25) return m.reply('Maksimal 25 detik!')
            await sock.vidToSticker(m.chat, buffer, m, {
              packname: packname,
              author: author
            })
            return
          } else if (/image/.test(type)) {
            await sock.imgToSticker(m.chat, buffer, m, {
              packname: packname,
              author: author
            })
            return
          }
        }
      }

      if (/image/.test(mime)) {
        let media = await sock.downloadAndSaveMediaMessage(quoted, +new Date * 1)
        await sock.imgToSticker(m.chat, media, m, {
          packname: packname,
          author: author
        })
        await fs.unlinkSync(media)
      } else if (/video/.test(mime)) {
        if ((quoted.msg || quoted).seconds > 25) return m.reply('Maksimal 25 detik!')
        let media = await sock.downloadAndSaveMediaMessage(quoted, +new Date * 1)
        await sock.vidToSticker(m.chat, media, m, {
          packname: packname,
          author: author
        })
        await fs.unlinkSync(media)
      } else if (/sticker/.test(mime)) {
        let media = await sock.downloadAndSaveMediaMessage(quoted, +new Date * 1)
        await sock.sendStickerFromUrl(m.chat, media, m, {
          packname: packname,
          author: author
        })
        await fs.unlinkSync(media)
      } else m.reply(`Kirim/kutip gambar dengan caption ${p_c}`)
    }
    break

    case 'brat': {
      if (!text) return m.reply(`Contoh: ${p_c} hai`)
      if (text.length > 250) return m.reply(`Karakter terbatas, max 250!`)
      react()
      let res = await fetch(`https://aqul-brat.hf.space/?text=${encodeURIComponent(text)}`)
      let buffer = await res.buffer()
      await sock.sendImageAsSticker(m.chat, buffer, m, {
        packname: packname,
        author: author
      })
    }
    break
    case 'tourl':
    case 'tolink': {
      if (!/image/.test(mime) && !/video/.test(mime) && !/audio/.test(mime) && !/webp/.test(mime)) return m.reply('Harus berupa video, gambar, audio, atau stiker')
      react()
      let media = await sock.downloadAndSaveMediaMessage(quoted)
      try {
        const catBoxUrl = await CatBox(media)
        const result = `📦 *CatBox*: ${catBoxUrl || '-'}`
        await m.reply(result)
      } catch (err) {
        console.error(err)
      } finally {
        await fs.unlinkSync(media)
      }
    }
    break

    case 'removebg':
    case 'nobg': {
      if (!/image/.test(mime)) return m.reply(`Kirim/kutip gambar/stiker dengan caption ${p_c}`)
      react()
      let {
        removeBg
      } = require('./lib/scrape')
      let img = await quoted.download()
      let image = await removeBg(img)
      let result = await Buffer.from(image, "base64")
      sock.sendImage(m.chat, result, `© ${wm}`, m)
    }
    break

    case 'hd':
    case 'hdr':
    case 'remini': {
      if (!/image/.test(mime)) return m.reply(`Kirim/kutip gambar dengan caption ${p_c}`)
      react()

      const {
        upScale,
        remini,
        Pxpic
      } = require('./lib/scrape')
      const media = await sock.downloadAndSaveMediaMessage(quoted)

      const hasilnya = await Pxpic(media, 'enhance')
      if (hasilnya?.resultImageUrl) {
        await sock.sendMessage(m.chat, {
          image: {
            url: hasilnya.resultImageUrl
          },
          caption: 'Sukses'
        }, {
          quoted: qKyle
        })
        fs.unlinkSync(media)
        return
      }

      if (await upScale(media, sock, m, m.chat)) {
        fs.unlinkSync(media)
        return
      }

      const proses = await remini(media, 'enhance')
      if (proses) {
        await sock.sendMessage(m.chat, {
          image: proses,
          caption: 'Sukses'
        }, {
          quoted: qKyle
        })
      } else {
        m.reply('Terjadi kesalahan')
      }

      fs.unlinkSync(media)
    }
    break
    case 'pin':
    case 'pinsearch':
    case 'pinterest': {
      if (!text) return m.reply(`Contoh: ${p_c} animek`)
      react()
      try {
        let hasil = await pinterest(text)
        if (!hasil) return m.reply('Gambar tidak ditemukan.')

        await sock.sendMessage(
          m.chat, {
            image: {
              url: hasil
            },
            caption: `© ${wm}`,
          }, {
            quoted: qKyle
          }
        )
      } catch (err) {
        console.error(err.message)
        m.reply('Terjadi kesalahan')
      }
    }
    break

    case 'antilink': {
      if (!m.isGroup) return onlyGrup()
      if (!isAdmins) return onlyAdmin()
      if (args[0] === "on") {
        if (db.data.chats[m.chat].antilink) return m.reply('Sudah aktif sebelumnya')
        db.data.chats[m.chat].antilink = true
        m.reply('Sukses mengaktifkan antilink!')
      } else if (args[0] === "off") {
        if (!db.data.chats[m.chat].antilink) return m.reply('Sudah nonaktifkan sebelumnya')
        db.data.chats[m.chat].antilink = false
        m.reply('Sukses menonaktifkan antilink!')
      } else {
        m.reply('Perintah tidak dikenali. Gunakan "on" untuk mengaktifkan atau "off" untuk menonaktifkan.')
      }
    }
    break

    case 'antilinkgc': {
      if (!m.isGroup) return onlyGrup()
      if (!isAdmins) return onlyAdmin()
      if (args[0] === "on") {
        if (db.data.chats[m.chat].antilinkgc) return m.reply('Sudah aktif sebelumnya')
        db.data.chats[m.chat].antilinkgc = true
        m.reply('Sukses mengaktifkan antilinkgc!')
      } else if (args[0] === "off") {
        if (!db.data.chats[m.chat].antilinkgc) return m.reply('Sudah nonaktifkan sebelumnya')
        db.data.chats[m.chat].antilinkgc = false
        m.reply('Sukses menonaktifkan antilinkgc!')
      } else {
        m.reply('Perintah tidak dikenali. Gunakan "on" untuk mengaktifkan atau "off" untuk menonaktifkan.')
      }
    }
    break

    case 'welcome': {
      if (!m.isGroup) return onlyGrup()
      if (!isAdmins) return onlyAdmin()
      if (args[0] === "on") {
        if (db.data.chats[m.chat].welcome) return m.reply('Sudah aktif sebelumnya')
        db.data.chats[m.chat].welcome = true
        m.reply('Sukses mengaktifkan welcome!')
      } else if (args[0] === "off") {
        if (!db.data.chats[m.chat].welcome) return m.reply('Sudah nonaktifkan sebelumnya')
        db.data.chats[m.chat].welcome = false
        m.reply('Sukses menonaktifkan welcome!')
      } else {
        m.reply('Perintah tidak dikenali. Gunakan "on" untuk mengaktifkan atau "off" untuk menonaktifkan.')
      }
    }
    break

    case 'goodbye': {
      if (!m.isGroup) return onlyGrup()
      if (!isAdmins) return onlyAdmin()
      if (args[0] === "on") {
        if (db.data.chats[m.chat].goodbye) return m.reply('Sudah aktif sebelumnya')
        db.data.chats[m.chat].goodbye = true
        m.reply('Sukses mengaktifkan goodbye!')
      } else if (args[0] === "off") {
        if (!db.data.chats[m.chat].goodbye) return m.reply('Sudah nonaktifkan sebelumnya')
        db.data.chats[m.chat].goodbye = false
        m.reply('Sukses menonaktifkan goodbye!')
      } else {
        m.reply('Perintah tidak dikenali. Gunakan "on" untuk mengaktifkan atau "off" untuk menonaktifkan.')
      }
    }
    break
    case 'kick': {
      if (!m.isGroup) return onlyGrup()
      if (!isOwner && !isAdmins) return onlyAdmin()
      if (!isBotAdmins) return onlyBotAdmin()

      let users = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'

      try {
        const participants = await sock.groupMetadata(m.chat)
        const ownerNumber = global.owner + '@s.whatsapp.net'

        if (users === ownerNumber || users === botNumber) {
          return m.reply('Ga bisa ngeluarin admin utama atau bot.')
        }

        if (!participants.participants.some(p => p.id === users)) {
          return m.reply('Target nggak ada di grup.')
        }

        await sock.groupParticipantsUpdate(m.chat, [users], 'remove')
        m.reply('Sukses kick target.')
      } catch (err) {
        m.reply('Terjadi kesalahan.')
      }
    }
    break

    case 'warning':
    case 'warn': {
      if (!m.isGroup) return onlyGrup()
      if (!isAdmins) return onlyAdmin()
      if (!isBotAdmins) return onlyBotAdmin()

      let users = m.mentionedJid[0] ?
        m.mentionedJid[0] :
        m.quoted ?
        m.quoted.sender :
        text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'

      if (!users) return m.reply(`Tag/Reply target yang mau di-${command}`)
      if (owner.includes(users)) return m.reply('Tidak dapat melakukannya kepada Owner')

      if (!db.data.chats[m.chat].warn) db.data.chats[m.chat].warn = {}
      db.data.chats[m.chat].warn[users] = (db.data.chats[m.chat].warn[users] || 0) + 1

      const total = db.data.chats[m.chat].warn[users]

      sock.sendTextWithMentions(m.chat, `⚠️ Sukses *${command}* @${users.split('@')[0]}\nTotal Warning: ${total}/${setting.warnCount}`, m)

      if (total >= setting.warnCount) {
        if (!isAdmins || !isBotAdmins) return

        await sock.sendMessage(m.chat, {
          text: `🚫 @${users.split('@')[0]} telah mencapai ${total}/${setting.warnCount} warning dan akan dikeluarkan.`,
          mentions: [users]
        })

        await sock.groupParticipantsUpdate(m.chat, [users], 'remove')
        delete db.data.chats[m.chat].warn[users]
      }
    }
    break

    case 'unwarning':
    case 'unwarn': {
      if (!m.isGroup) return onlyGrup()
      if (!isAdmins) return onlyAdmin()
      if (!isBotAdmins) return onlyBotAdmin()

      let users = m.mentionedJid[0] ?
        m.mentionedJid[0] :
        m.quoted ?
        m.quoted.sender :
        text.replace(/[^0-9]/g, '') + '@s.whatsapp.net'

      if (!users) return m.reply(`Tag/Reply target yang mau di-${command}`)
      if (owner.includes(users)) return m.reply('Tidak dapat melakukan unwarn kepada Owner')

      if (!db.data.chats[m.chat].warn) db.data.chats[m.chat].warn = {}

      if (!db.data.chats[m.chat].warn[users] || db.data.chats[m.chat].warn[users] === 0) {
        return m.reply(`User tersebut belum memiliki warning.`)
      }

      db.data.chats[m.chat].warn[users] -= 1

      const sisa = db.data.chats[m.chat].warn[users]

      sock.sendTextWithMentions(m.chat, `✅ Sukses *${command}* @${users.split('@')[0]}\nSisa Warning: ${sisa}/${setting.warnCount}`, m)
      if (db.data.chats[m.chat].warn[users] === 0) {
        delete db.data.chats[m.chat].warn[m.sender];
      }
    }
    break

    case 'listwarn':
    case 'cekwarn': {
      if (!m.isGroup) return onlyGrup()
      if (!isAdmins) return onlyAdmin()

      let warnData = db.data.chats[m.chat].warn
      if (!warnData || Object.keys(warnData).length === 0) {
        return m.reply('Tidak ada member yang memiliki warning di grup ini.')
      }

      let teks = `⚠️ *Daftar Warning Member Grup:*\n\n`
      let no = 1

      for (let jid in warnData) {
        teks += `${no++}. @${jid.split('@')[0]} - ${warnData[jid]}/${setting.warnCount} warning\n`
      }

      await sock.sendTextWithMentions(m.chat, teks, m)
    }
    break
    case 'h':
    case 'ht':
    case 'hidetag': {
      if (!m.isGroup) return onlyGrup()
      if (!isOwner && !isAdmins) return onlyOa()
      if (m.quoted) {
        await sock.sendMessage(m.chat, {
          forward: m.quoted.fakeObj,
          mentions: participants.map(a => a.id)
        })
      }
      if (!m.quoted) {
        await sock.sendMessage(m.chat, {
          text: q ? q : '',
          mentions: participants.map(a => a.id)
        }, {
          quoted: qKyle
        })
      }
    }
    break

    case 'open':
    case 'bukagc':
    case 'buka': {
      if (!m.isGroup) return onlyGrup()
      if (!isOwner && !isAdmins) return onlyAdmin()
      if (!isBotAdmins) return onlyBotAdmin()
      sock.groupSettingUpdate(m.chat, 'not_announcement')
      m.reply(`Sukses membuka grup`)
    }
    break

    case 'close':
    case 'tutupgc':
    case 'tutup': {
      if (!m.isGroup) return onlyGrup()
      if (!isOwner && !isAdmins) return onlyAdmin()
      if (!isBotAdmins) return onlyBotAdmin()
      sock.groupSettingUpdate(m.chat, 'announcement')
      m.reply(`Sukses menutup grup`)
    }
    break

    case 'resetlink':
    case 'revoke': {
      if (!m.isGroup) return onlyGrup()
      if (!isOwner && !isAdmins) return onlyAdmin()
      if (!isBotAdmins) return onlyBotAdmin()
      await sock.groupRevokeInvite(m.chat)
        .then(res => {
          m.reply(`Sukses menyetel ulang link grup`)
        }).catch(() => m.reply('Terjadi kesalahan'))
    }
    break
    case 'addown':
    case 'addowner': {
      if (!isOwner) return onlyOwn();
      if (!args[0]) return m.reply(`Contoh: ${p_c} tag/kutip`);
      let users = m.mentionedJid[0] ?
        m.mentionedJid[0] :
        m.quoted ?
        m.quoted.sender :
        text.replace(/[^0-9]/g, '');
      let getusers = users.replace(/[^0-9]/g, '');
      if (own.includes(getusers)) return m.reply('User sudah ada di daftar owner!');
      own.push(getusers);
      fs.writeFileSync('./database/owner.json', JSON.stringify(own, null, 2));
      m.reply('Berhasil addowner');
    }
    break

    case 'delown':
    case 'delowner': {
      if (!isOwner) return onlyOwn();
      if (!args[0]) return m.reply(`Contoh: ${p_c} tag/kutip`);
      let users = m.mentionedJid[0] ?
        m.mentionedJid[0] :
        m.quoted ?
        m.quoted.sender :
        q.split('|')[0].replace(/[^0-9]/g, '');
      const index = own.indexOf(users);
      if (index === -1) return m.reply('User tidak ditemukan di daftar owner!');
      own.splice(index, 1);
      fs.writeFileSync('./database/owner.json', JSON.stringify(own, null, 2));
      m.reply('Berhasil delowner');
    }
    break

    case 'listown':
    case 'listowner': {
      if (!isOwner) return onlyOwn();
      let teks = `List owner\nTotal: ${own.length}\n\n`;
      for (let kon of own) {
        teks += `• ${kon}\n`;
      }
      m.reply(teks);
    }
    break
    case 'backup': {
      if (!isOwner) return onlyOwn()
      try {
        const {
          execSync
        } = require("child_process");
        const ls = (await execSync("ls")).toString().split("\n").filter((pe) =>
          pe != "node_modules" &&
          pe != "session" &&
          pe != "package-lock.json" &&
          pe != "yarn.lock" &&
          pe != "");
        const exec = await execSync(`zip -r Backup.zip ${ls.join(" ")}`);
        await sock.sendMessage(m.isGroup ? owner + '@s.whatsapp.net' : from, {
          document: await fs.readFileSync('./Backup.zip'),
          mimetype: "application/zip",
          fileName: "Backup.zip",
        }, {
          quoted: qKyle
        });
        await execSync("rm -rf Backup.zip");
      } catch (err) {
        m.reply('Terjadi kesalahan')
      }
    }
    break
    case 'public': {
      if (!isOwner) return onlyOwn()
      setting.public = true
      fs.writeFileSync('./settingsjson', JSON.stringify(setting, null, 2))
      m.reply('Sukses mengubah ke mode public')
    }
    break

    case 'self': {
      if (!isOwner) return onlyOwn()
      setting.public = false
      fs.writeFileSync('./settingsjson', JSON.stringify(setting, null, 2))
      m.reply('Sukses mengubah ke mode self')
    }
    break
    default:


    }

  } catch (err) {
    console.log(err)
  }
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(`Update ${__filename}`)
  delete require.cache[file]
  require(file)
})