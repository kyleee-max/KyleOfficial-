const fs = require('fs')
const pack = require('./package.json')
global.pairing = false // false = pairing code | true = scan QR
global.PaiCode = "KYLETAMV" // Wajib 8 digit pairing code (custom)
global.broswer = "Firefox" // Server Browser 
global.sessionName = "session" // Nama file session

global.botname = "SparkleSoft" // Bot name
global.ownername = "Kyle Tamv" // Owner name
global.owner = "6283854859219" // Owner number
global.botNumber = "628386859765" //  Bot number
global.version = pack.version // Version
global.foot = "KyleDevTamvan" // Footer
global.packname = "Sparkle" // Sticker packname 
global.author = "Kyle" // Sticker author

global.wm = "New bot" // Watermark thumbnail
global.thumb = "https://files.catbox.moe/assqrw.jpg" // Thumbnail bot 

let file = require.resolve(__filename)
fs.watchFile(file, () => {
  fs.unwatchFile(file)
  console.log(`Update ${__filename}`)
  delete require.cache[file]
  require(file)
})