import Link from 'next/link'
export default function Sidebar(){
  return (
    <aside className="sidebar">
      <div className="logo">KyleOfficial</div>
      <nav>
        <Link href="/" className="btn">Home</Link>
        <Link href="/products" className="btn">List Jualan</Link>
        <Link href="/dashboard" className="btn">Info Akun</Link>
        <Link href="#" className="btn">Menu Lainnya</Link>
      </nav>
    </aside>
  )
}
