import Layout from '../components/Layout'
import { useEffect, useState } from 'react'

export default function Dashboard(){
  const [me,setMe]=useState(null)
  useEffect(()=>{
    fetch('/api/auth/me').then(r=>r.json()).then(d=>{ if(d?.email) setMe(d) })
  },[])
  return (
    <Layout>
      <div className="card">
        <h1 className="h1">Info Akun</h1>
        <p className="lead">Detail akun dan klaim garansi.</p>
        {me ? <div><p className="lead">Email: {me.email}</p></div> : <div className="lead">Silakan login untuk lihat info.</div>}
      </div>
    </Layout>
  )
}
