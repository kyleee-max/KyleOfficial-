import Layout from '../components/Layout'
import { useState } from 'react'
import { useRouter } from 'next/router'

export default function Login(){
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')
  const [msg,setMsg]=useState('')
  const r = useRouter()
  const submit = async (e)=>{
    e.preventDefault()
    const res = await fetch('/api/auth/login',{method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({email,password})})
    const j = await res.json()
    if(res.ok) r.push('/dashboard')
    else setMsg(j.error || 'Login failed')
  }
  return (
    <Layout>
      <div className="card">
        <h1 className="h1">Login</h1>
        <p className="lead">Masuk untuk mengklaim garansi dan lihat info akun.</p>
        <form onSubmit={submit} className="login-form">
          <input className="input" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
          <input type="password" className="input" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)} />
          <button className="primary">Login</button>
          {msg && <p className="lead">{msg}</p>}
        </form>
      </div>
    </Layout>
  )
}
