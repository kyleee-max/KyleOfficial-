import Layout from '../../components/Layout'
import { useEffect, useState } from 'react'

export default function Products(){
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  useEffect(()=>{
    fetch('/api/products').then(r=>r.json()).then(d=>{setData(d); setLoading(false)}).catch(e=>{setLoading(false)})
  },[])
  return (
    <Layout>
      <div className="card">
        <h1 className="h1">List Jualan</h1>
        <p className="lead">Produk & layanan yang tersedia.</p>
        <div className="product-grid">
          {loading && <div>Loading...</div>}
          {data && data.length===0 && <div className="lead">Belum ada produk.</div>}
          {data?.map(p=> (
            <div key={p._id} className="product">
              <h3>{p.name}</h3>
              <p className="lead">{p.price}</p>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  )
}
