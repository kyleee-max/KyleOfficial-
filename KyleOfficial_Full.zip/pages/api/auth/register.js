import clientPromise from '../../../../lib/mongodb'
import bcrypt from 'bcryptjs'

export default async function handler(req,res){
  if(req.method!=='POST') return res.status(405).end()
  const {email,password,name} = req.body
  if(!email || !password) return res.status(400).json({error:'Missing fields'})
  const client = await clientPromise
  const db = client.db('kyleofficial')
  const existing = await db.collection('users').findOne({email})
  if(existing) return res.status(409).json({error:'Email exists'})
  const hash = await bcrypt.hash(password,10)
  const r = await db.collection('users').insertOne({email, password:hash, name: name||'', createdAt:new Date()})
  res.json({ok:true})
}
