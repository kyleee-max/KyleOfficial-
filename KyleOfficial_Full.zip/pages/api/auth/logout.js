import { serialize } from 'cookie'
export default function handler(req,res){
  res.setHeader('Set-Cookie', serialize('kyle_token','', {httpOnly:true, path:'/', maxAge:0}))
  res.json({ok:true})
}
