import clientPromise from '../../../../lib/mongodb'
import jwt from 'jsonwebtoken'

export default async function handler(req,res){
  const token = req.cookies?.kyle_token
  if(!token) return res.json({})
  try{
    const payload = jwt.verify(token, process.env.JWT_SECRET)
    const client = await clientPromise
    const db = client.db('kyleofficial')
    const user = await db.collection('users').findOne({_id: new (require('mongodb')).ObjectId(payload.uid)})
    if(!user) return res.json({})
    return res.json({email:user.email, name:user.name||''})
  }catch(e){
    return res.json({})
  }
}
