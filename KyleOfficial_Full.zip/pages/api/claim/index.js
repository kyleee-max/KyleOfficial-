import clientPromise from '../../../../lib/mongodb'
import jwt from 'jsonwebtoken'

export default async function handler(req,res){
  if(req.method!=='POST') return res.status(405).end()
  const {productId, note} = req.body
  const token = req.cookies?.kyle_token
  if(!token) return res.status(401).json({error:'Not logged in'})
  let payload
  try{ payload = jwt.verify(token, process.env.JWT_SECRET) }catch(e){return res.status(401).json({error:'Invalid token'})}
  const client = await clientPromise
  const db = client.db('kyleofficial')
  const claim = { productId, note, userId: payload.uid, createdAt: new Date(), status:'pending' }
  const r = await db.collection('claims').insertOne(claim)
  res.json({ok:true, id:r.insertedId})
}
