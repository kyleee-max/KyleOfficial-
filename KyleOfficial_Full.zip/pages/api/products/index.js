import clientPromise from '../../../../lib/mongodb'

export default async function handler(req,res){
  const client = await clientPromise
  const db = client.db('kyleofficial')
  if(req.method==='GET'){
    const prods = await db.collection('products').find({}).toArray()
    res.json(prods)
  } else if (req.method==='POST'){
    const body = req.body
    const newP = await db.collection('products').insertOne({name:body.name||'Unnamed', price:body.price||'0', createdAt:new Date()})
    res.json({ok:true, id:newP.insertedId})
  } else res.status(405).end()
}
