import Layout from '../components/Layout'
export default function Home(){
  return (
    <Layout>
      <div className="card">
        <h1 className="h1">Welcome to KyleOfficial</h1>
        <p className="lead">Portal resmi — beli layanan, klaim garansi, dan cek status akun kamu.</p>
      </div>
      <div style={{height:18}} />
      <div className="card">
        <h2 className="h1">About</h2>
        <p className="lead">This is a starter project. Customize content and backend logic as needed.</p>
      </div>
    </Layout>
  )
}
