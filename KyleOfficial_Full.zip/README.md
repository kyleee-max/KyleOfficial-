# KyleOfficial - Starter (Next.js fullstack)

Starter project siap deploy ke Vercel.

## Cara pakai singkat
1. Salin `.env.example` ke `.env.local` dan isi `MONGODB_URI` serta `JWT_SECRET`.
2. Jalankan `npm install` lalu `npm run dev` untuk testing lokal.
3. Push repo ke GitHub atau zip folder ini dan import manual ke Vercel.

## Environment variables
- MONGODB_URI
- JWT_SECRET

## Notes
- Pastikan set env vars di Vercel Project Settings sebelum deploy.
- Untuk produksi, tambahkan rate limiting dan validasi input.
