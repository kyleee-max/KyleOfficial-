/*━━━━━━━━━━━━━━━━━━━━━━━━━━╼
THIS SCRIPT RECODE BY KYLEOFFIC
INITIAL SCRIPT BY ZASSBTC
SUPPORT BY CANSS
DONT DELETED CREADIT FOR SUPPORT CREATOR
╾━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╼
*/
const fs = require('fs')
const chalk = require('chalk')

//━━━━━━━━━━━━𓊈SET OWNER𓊉━━━━━━━━━━━━━//
global.location = "Ngawi Barat"
global.ownername = "KyleDev"
global.ownernumber = "6281316071460"
global.ownerbut = ['6281316071460@s.whatsapp.net']
//━━━━━━━━━━━━𓊈SET BOT𓊉━━━━━━━━━━━━━━//
global.adminonly = true,
global.botname = 'Hoshino Assisten'
global.versi = '3.1'
global.foot = '©Hoshino Ai'
global.aiUsageCount = global.aiUsageCount || {};
global.hias = "➤"
global.pairing = "KYLEOFIC"

//━━━━━━━━━━━━𓊈SET STICKER𓊉━━━━━━━━━━━━━//
global.packname = 'Hoshino-Bot'
global.author = `\n KYLE`
global.themeemoji = '🪀'
global.wm = "Hoshino-Ai"
global.reactLoading = '👌🏻'
global.prefa = ['!','.']
//━━━━━━━━━━━━𓊈SET THUMB𓊉━━━━━━━━━━━━━//
global.imgthumb = "https://files.catbox.moe/8vbjf4.jpg" //thumb menu
global.imgmenu = "https://files.catbox.moe/y6302v.jpg" //thumb menu2
//━━━━━━━━━━━━━━𓊈BATAS𓊉━━━━━━━━━━━━━━━//
  
let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update'${__filename}'`))
    delete require.cache[file]
    require(file)
})