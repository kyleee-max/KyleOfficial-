require('./settings')
const pino = require('pino')
const { Boom } = require('@hapi/boom')
const fs = require('fs')
const chalk = require('chalk')
const FileType = require('file-type')
const path = require('path')
const axios = require('axios')
const PhoneNumber = require('awesome-phonenumber')
const { imageToWebp, videoToWebp, writeExifImg, writeExifVid } = require('./lib/exif')
const { smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, fetch, await, sleep, reSize, loadModule } = require('./lib/myfunc')
const matrix = require('./lib/connect/matrix.js');
const { default: neoConnect, delay, makeCacheableSignalKeyStore, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, generateForwardMessageContent, prepareWAMessageMedia, generateWAMessageFromContent, generateMessageID, downloadContentFromMessage, makeInMemoryStore, jidDecode, proto, Browsers} = require("naruyaizumi")
const NodeCache = require("node-cache")
const Pino = require("pino")
const readline = require("readline")
const { parsePhoneNumber } = require("libphonenumber-js")

const { rankDB, updateRank, saveRank } = require('./lib/rank.js')

const makeWASocket = require("naruyaizumi").default
const { execSync } = require("child_process");

const requiredModules = [
  "naruyaizumi",
  "pino",
  "chalk",
  "figlet",
  "ora"
];

for (const mod of requiredModules) {
  try {
    require.resolve(mod);
  } catch (err) {
    console.log(`[ Auto Install ] Module ${mod} belum ada. Menginstall...`);
    execSync(`npm install ${mod}`, { stdio: "inherit" });
  }
}
const store = makeInMemoryStore({
    logger: pino().child({
        level: 'silent',
        stream: 'store'
    })
})

// Func load feature 
function loadCase() {
  let file = fs.readFileSync("./Kyle.js", "utf-8"); // handler utama mu
  let lines = file.split("\n");
  let menu = {};
  let currentCategory = null;

  for (let line of lines) {
    // Deteksi kategori (pakai komentar pembatas)
    let catMatch = line.match(/\/\/—+\[ Menu (.+?) \]—+\/\//i);
    if (catMatch) {
      currentCategory = catMatch[1].trim();
      if (!menu[currentCategory]) menu[currentCategory] = [];
    }

    // Deteksi case (baik pakai '' atau "")
    let caseMatch = line.match(/case\s+['"]([^'"]+)['"]\s*:/i);
    if (caseMatch && currentCategory) {
      menu[currentCategory].push(caseMatch[1]);
    }
  }

  global.menucase = menu;
  console.log("Case Loaded:", menu);
}

let phoneNumber = null
let owner = JSON.parse(fs.readFileSync('./database/owner.json'))
const db = './database/set.json'

const pairingCode = !!phoneNumber || process.argv.includes("--pairing-code")
const useMobile = process.argv.includes("--mobile")

const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
const question = (text) => new Promise((resolve) => rl.question(text, resolve))

async function startKyle() {
  await loadCase();
  await matrix();

  const { version } = await fetchLatestBaileysVersion();
  const { state, saveCreds } = await useMultiFileAuthState('./session');
  const msgRetryCounterCache = new NodeCache();

  const Kyle = makeWASocket({
    version,
    logger: Pino({ level: 'silent' }),
    browser: Browsers.windows('Firefox'),
    printQRInTerminal: !process.argv.includes("--pairing-code"),
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, Pino({ level: "fatal" })),
    },
    msgRetryCounterCache,
    generateHighQualityLinkPreview: true,
    markOnlineOnConnect: true,
    getMessage: async (key) => {
      const jid = jidNormalizedUser(key.remoteJid);
      const msg = await store.loadMessage(jid, key.id);
      return msg?.message || "";
    },
  });

  store.bind(Kyle.ev);

  const isPairing = process.argv.includes("--pairing-code");
  const pairingName = global.pairing;

  if (isPairing && !Kyle.authState.creds.registered) {
    console.log(chalk.cyan(`\n[global.botname] Enter WhatsApp number :`));
    let nomor = await question(chalk.cyan(`Contoh: +62xxx : `));
    nomor = nomor.replace(/[^0-9]/g, '');

    console.log(chalk.green(`\n😈 Target Ewe: ${chalk.bold(nomor)}`));

    setTimeout(async () => {
      try {
        const code = await Kyle.requestPairingCode(nomor, pairingName);
        const format = code?.match(/.{1,4}/g)?.join("-") || code;
        console.log(chalk.bgGreen.black(" Here's the pairing "), chalk.white.bold(format));
      } catch (err) {
        console.error(chalk.red("Gagal mengambil pairing code!"), err);
      }
    }, 3000);
  }

    Kyle.ev.on('messages.upsert', async chatUpdate => {
        //console.log(JSON.stringify(chatUpdate, undefined, 2))
        try {
            const mek = chatUpdate.messages[0]
            if (!mek.message) return
            mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage') ? mek.message.ephemeralMessage.message : mek.message
            if (mek.key && mek.key.remoteJid === 'status@broadcast' )
            if (!Kyle.public && !mek.key.fromMe && chatUpdate.type === 'notify') return
            if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return
            const m = smsg(Kyle, mek, store)
            if (m.key && m.key.fromMe === false) { // hanya user, bukan bot sendiri
    const groupId = m.chat
    const userId = m.sender
    const pushName = m.pushName || 'Unknown'
    const isCreator = global.ownerbut
    if (groupId.endsWith('@g.us')) {
    // skip owner
    if (isCreator || global.owner?.includes(userId)) { 
    if (!rankDB[groupId]) rankDB[groupId] = {}
    if (!rankDB[groupId][userId]) {
        rankDB[groupId][userId] = { 
            messages: 0, 
            rank: 'Warrior', 
            name: pushName,
           lastSeen: Date.now() // waktu pertama kali join/tercatat
        }
    }
    rankDB[groupId][userId].messages += 1
   rankDB[groupId][userId].name = pushName
    rankDB[groupId][userId].lastSeen = Date.now() // update tiap kali user chat
    updateRank(groupId, userId)
}
}}
            require("./Kyle")(Kyle, m, chatUpdate, store)
        } catch (err) {
            console.log(err)
        }
    })

    Kyle.ev.on('messages.upsert', async chatUpdate => {
        try {
        mek = chatUpdate.messages[0];
        if (!mek || !mek.key) return;

        // Auto view status jika aktif
        if (mek.key.remoteJid === 'status@broadcast' && db.settings.autoview) {
            await Kyle.readMessages([mek.key]);
        }
    } catch (err) {
        console.error('AutoView Error:', err);
    }
});

    
    Kyle.decodeJid = (jid) => {
        if (!jid) return jid
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {}
            return decode.user && decode.server && decode.user + '@' + decode.server || jid
        } else return jid
    }

    Kyle.ev.on('contacts.update', update => {
        for (let contact of update) {
            let id = Kyle.decodeJid(contact.id)
            if (store && store.contacts) store.contacts[id] = {
                id,
                name: contact.notify
            }
        }
    })
function loadDB() {

  try {

    return JSON.parse(fs.readFileSync(db, "utf-8"));

  } catch(e) {

    console.error("Gagal load set.json:", e);

    return {};

  }

}

// Event listener

Kyle.ev.on('group-participants.update', async (anu) => {

  let mok = loadDB(); // load terbaru tiap event
  let { id, participants, action } = anu;
  if (!mok.groups) mok.groups = {};
  if (!mok.groups[id]) mok.groups[id] = { welcome: false, goodbye: false };
try {
    const groupMetadata = await Kyle.groupMetadata(id);
    const groupName = groupMetadata.subject || "Grup ini";
    for (let num of participants) {
      let userTag = '@' + num.split('@')[0];
      let ppUrl = global.imgmenu
     const qCans = {
  key: { participant: "0@s.whatsapp.net", remoteJid: "status@broadcast" },
  message: { contactMessage: { displayName: global.ownername, isBusinessVerified: true } }
};
if (action === "add" && mok.groups[id].welcome) {
  let teks = (mok.groups[id].welcomeText || `Selamat datang ${userTag} di grup *${groupName}*!`)
    .replace(/@user/gi, userTag)
    .replace(/@group/gi, groupName);
  const msg = await generateWAMessageFromContent(
    id,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: proto.Message.InteractiveMessage.create({
           body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({buttons: [
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "Intro 📝",
                   id: ".intro"
                  })
                }
              ]
            })
          })
        }
      }
    },
    { quoted: qCans }
  );
  await Kyle.relayMessage(id, msg.message, { messageId: msg.key.id });
} else if (action === 'remove' && mok.groups[id].goodbye) {
  let teks = (mok.groups[id].goodbyeText || 
    `Selamat tinggal ${userTag}, semoga betah di luar *${groupName}* 👋`)
    .replace(/@user/gi, userTag)
    .replace(/@group/gi, groupName);
  const msg = await generateWAMessageFromContent(
    id,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: proto.Message.InteractiveMessage.create({
            body: proto.Message.InteractiveMessage.Body.create({ text: teks }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {
                  name: "quick_reply",
                  buttonParamsJson: JSON.stringify({
                    display_text: "Goodbye 👋",
                    id: "byee"
                  })
                }
              ]
            })
          })
        }
     }
    },
    { quoted: qCans } // ini pake qCans yang tadi
  );
  await Kyle.relayMessage(id, msg.message, { messageId: msg.key.id });
}
}
} catch (e) {
    console.log("Welcome/Goodbye error:", e.message);
  }
});

    Kyle.getName = (jid, withoutContact = false) => {
        id = Kyle.decodeJid(jid)
        withoutContact = Kyle.withoutContact || withoutContact
        let v
        if (id.endsWith("@g.us")) return new Promise(async (resolve) => {
            v = store.contacts[id] || {}
            if (!(v.name || v.subject)) v = Kyle.groupMetadata(id) || {}
            resolve(v.name || v.subject || PhoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international'))
        })
        else v = id === '0@s.whatsapp.net' ? {
                id,
                name: 'WhatsApp'
            } : id === Kyle.decodeJid(Kyle.user.id) ?
            Kyle.user :
            (store.contacts[id] || {})
        return (withoutContact ? '' : v.name) || v.subject || v.verifiedName || PhoneNumber('+' + jid.replace('@s.whatsapp.net', '')).getNumber('international')
    }

    global.selfmode = false
    Kyle.public = true

    Kyle.serializeM = (m) => smsg(Kyle, m, store)

Kyle.ev.on("connection.update",async  (s) => {
        const { connection, lastDisconnect } = s
        if (connection == "open") {
            console.log(chalk.magenta(`< # > Bot Berhasil Tersambung!`))
            await loadModule(Kyle);
        }
        if (
            connection === "close" &&
            lastDisconnect &&
            lastDisconnect.error &&
            lastDisconnect.error.output.statusCode != 401
        ) {
            startKyle()
        }
    })
    Kyle.ev.on('creds.update', saveCreds)
    Kyle.ev.on("messages.upsert",  () => { })

    Kyle.sendText = (jid, text, quoted = '', options) => Kyle.sendMessage(jid, {
        text: text,
        ...options
    }, {
        quoted,
        ...options
    })
    Kyle.sendTextWithMentions = async (jid, text, quoted, options = {}) => Kyle.sendMessage(jid, {
        text: text,
        mentions: [...text.matchAll(/@(\d{0,16})/g)].map(v => v[1] + '@s.whatsapp.net'),
        ...options
    }, {
        quoted
    })
    Kyle.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
        let buffer
        if (options && (options.packname || options.author)) {
            buffer = await writeExifImg(buff, options)
        } else {
            buffer = await imageToWebp(buff)
        }

        await Kyle.sendMessage(jid, {
            sticker: {
                url: buffer
            },
            ...options
        }, {
            quoted
        })
        return buffer
    }
    Kyle.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
        let buff = Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split`,` [1], 'base64') : /^https?:\/\//.test(path) ? await (await getBuffer(path)) : fs.existsSync(path) ? fs.readFileSync(path) : Buffer.alloc(0)
        let buffer
        if (options && (options.packname || options.author)) {
            buffer = await writeExifVid(buff, options)
        } else {
            buffer = await videoToWebp(buff)
        }

        await Kyle.sendMessage(jid, {
            sticker: {
                url: buffer
            },
            ...options
        }, {
            quoted
        })
        return buffer
    }
    Kyle.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
        let quoted = message.msg ? message.msg : message
        let mime = (message.msg || message).mimetype || ''
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
        const stream = await downloadContentFromMessage(quoted, messageType)
        let buffer = Buffer.from([])
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk])
        }
        let type = await FileType.fromBuffer(buffer)
        trueFileName = attachExtension ? (filename + '.' + type.ext) : filename
        // save to file
        await fs.writeFileSync(trueFileName, buffer)
        return trueFileName
    }

    Kyle.getFile = async (PATH, save) => {
        let res
        let data = Buffer.isBuffer(PATH) ? PATH : /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split`,`[1], 'base64') : /^https?:\/\//.test(PATH) ? await (res = await getBuffer(PATH)) : fs.existsSync(PATH) ? (filename = PATH, fs.readFileSync(PATH)) : typeof PATH === 'string' ? PATH : Buffer.alloc(0)
        //if (!Buffer.isBuffer(data)) throw new TypeError('Result is not a buffer')
        let type = await FileType.fromBuffer(data) || {
            mime: 'application/octet-stream',
            ext: '.bin'
        }
        filename = path.join(__filename, '../src/' + new Date * 1 + '.' + type.ext)
        if (data && save) fs.promises.writeFile(filename,
        data)
        return {
            res,
            filename,
	    size: await getSizeMedia(data),
            ...type,
            data
        }

    }

    Kyle.sendFile = async (jid, path, filename = '', caption = '', quoted, ptt = false, options = {}) => {
  let type = await Kyle.getFile(path, true);
  let { res, data: file, filename: pathFile } = type;

  if (res && res.status !== 200 || file.length <= 65536) {
    try {
      throw {
        json: JSON.parse(file.toString())
      };
    } catch (e) {
      if (e.json) throw e.json;
    }
  }

  let opt = {
    filename
  };

  if (quoted) opt.quoted = quoted;
  if (!type) options.asDocument = true;

  let mtype = '',
    mimetype = type.mime,
    convert;
  
  if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = 'sticker';
  else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = 'image';
  else if (/video/.test(type.mime)) mtype = 'video';
  else if (/audio/.test(type.mime)) {
    convert = await (ptt ? toPTT : toAudio)(file, type.ext);
    file = convert.data;
    pathFile = convert.filename;
    mtype = 'audio';
    mimetype = 'audio/ogg; codecs=opus';
  } else mtype = 'document';

  if (options.asDocument) mtype = 'document';

  delete options.asSticker;
  delete options.asLocation;
  delete options.asVideo;
  delete options.asDocument;
  delete options.asImage;

  let message = { ...options, caption, ptt, [mtype]: { url: pathFile }, mimetype };
  let m;

  try {
    m = await Kyle.sendMessage(jid, message, { ...opt, ...options });
  } catch (e) {
    //console.error(e)
    m = null;
  } finally {
    if (!m) m = await Kyle.sendMessage(jid, { ...message, [mtype]: file }, { ...opt, ...options });
    file = null;
    return m;
  }
}

    Kyle.downloadMediaMessage = async (message) => {
        let mime = (message.msg || message).mimetype || ''
        let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
        const stream = await downloadContentFromMessage(message, messageType)
        let buffer = Buffer.from([])
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk])
        }

        return buffer
    }
    }
return startKyle()

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update ${__filename}`))
    delete require.cache[file]
    require(file)
})

process.on('uncaughtException', function (err) {
let e = String(err)
/*if (e.includes("conflict")) return
if (e.includes("Socket connection timeout")) return
if (e.includes("not-authorized")) return
if (e.includes("already-exists")) return
if (e.includes("rate-overlimit")) return
if (e.includes("Connection Closed")) return
if (e.includes("Timed Out")) return
if (e.includes("Value not found")) return*/
console.log('Caught exception: ', err)
})